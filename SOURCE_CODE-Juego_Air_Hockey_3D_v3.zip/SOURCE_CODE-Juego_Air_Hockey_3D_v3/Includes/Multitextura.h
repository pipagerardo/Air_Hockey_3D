//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 31/03/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// -- Multitextura.h -----------------------------------------------------------
// -----------------------------------------------------------------------------
// #include "../Includes/Multitextura.h"
//
// // -- CREACION DEL MULTITEXTURA -----------------------------------------------
// if ( sdl_con_opengl->Multitexture ) Inicia_Multitextura();
// else {
//   cerr << "Tu Tarjeta Grafica no es compatible con Multitextura." << endl;
//   exit(1);
// }
// /* sdl_con_opengl->Texture_Units_ARB */
//
// glActiveTextureARB( GL_TEXTURE0_ARB );
// textura_2D[0].activa();
// glActiveTextureARB( GL_TEXTURE1_ARB );
// textura_2D[1].activa();
// glBegin( GL_QUADS );
//   glNormal3f( 0.0f, 0.0f, 1.0f );
//   glMultiTexCoord2fARB( GL_TEXTURE0_ARB, 0.0f, 0.0f );
// 	 glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 0.0f, 0.0f );
//   glVertex3i( -1,  1, 0 );
//   glMultiTexCoord2fARB( GL_TEXTURE0_ARB, 0.0f, 1.0f );
// 	 glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 0.0f, 1.0f );
//   glVertex3i( -1, -1, 0 );
//   glMultiTexCoord2fARB( GL_TEXTURE0_ARB, 1.0f, 1.0f );
// 	 glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 1.0f, 1.0f );
//   glVertex3i(  1, -1, 0 );
//   glMultiTexCoord2fARB( GL_TEXTURE0_ARB, 1.0f, 0.0f );
// 	 glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 1.0f, 0.0f );
//   glVertex3i(  1,  1, 0 );
// glEnd();
//       
// glActiveTextureARB( GL_TEXTURE1_ARB );     
// textura_2D[1].desactiva();
// glActiveTextureARB( GL_TEXTURE0_ARB );  
// textura_2D[0].desactiva();
// 
// -----------------------------------------------------------------------------
#ifndef _Multitextura_
#define _Multitextura_

// #include <iostream>
// using namespace std;
// #include <cstring>
#include <GL/gl.h>										
#include <GL/glu.h>										
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

#ifndef GL_ARB_multitexture
#define GL_ARB_multitexture               1
#define GL_TEXTURE0_ARB                   0x84C0
#define GL_TEXTURE1_ARB                   0x84C1
#define GL_TEXTURE2_ARB                   0x84C2
#define GL_TEXTURE3_ARB                   0x84C3
#define GL_TEXTURE4_ARB                   0x84C4
#define GL_TEXTURE5_ARB                   0x84C5
#define GL_TEXTURE6_ARB                   0x84C6
#define GL_TEXTURE7_ARB                   0x84C7
#define GL_TEXTURE8_ARB                   0x84C8
#define GL_TEXTURE9_ARB                   0x84C9
#define GL_TEXTURE10_ARB                  0x84CA
#define GL_TEXTURE11_ARB                  0x84CB
#define GL_TEXTURE12_ARB                  0x84CC
#define GL_TEXTURE13_ARB                  0x84CD
#define GL_TEXTURE14_ARB                  0x84CE
#define GL_TEXTURE15_ARB                  0x84CF
#define GL_TEXTURE16_ARB                  0x84D0
#define GL_TEXTURE17_ARB                  0x84D1
#define GL_TEXTURE18_ARB                  0x84D2
#define GL_TEXTURE19_ARB                  0x84D3
#define GL_TEXTURE20_ARB                  0x84D4
#define GL_TEXTURE21_ARB                  0x84D5
#define GL_TEXTURE22_ARB                  0x84D6
#define GL_TEXTURE23_ARB                  0x84D7
#define GL_TEXTURE24_ARB                  0x84D8
#define GL_TEXTURE25_ARB                  0x84D9
#define GL_TEXTURE26_ARB                  0x84DA
#define GL_TEXTURE27_ARB                  0x84DB
#define GL_TEXTURE28_ARB                  0x84DC
#define GL_TEXTURE29_ARB                  0x84DD
#define GL_TEXTURE30_ARB                  0x84DE
#define GL_TEXTURE31_ARB                  0x84DF
#define GL_ACTIVE_TEXTURE_ARB             0x84E0
#define GL_CLIENT_ACTIVE_TEXTURE_ARB      0x84E1
#define GL_MAX_TEXTURE_UNITS_ARB          0x84E2
#endif

typedef void (APIENTRY * GL_MultiTexCoord2fARB)(unsigned int,float,float);
typedef void (APIENTRY * GL_ActiveTextureARB)  (unsigned int);

extern GL_MultiTexCoord2fARB  glMultiTexCoord2fARB;
extern GL_ActiveTextureARB    glActiveTextureARB;  

void Inicia_Multitextura( void );

#endif
