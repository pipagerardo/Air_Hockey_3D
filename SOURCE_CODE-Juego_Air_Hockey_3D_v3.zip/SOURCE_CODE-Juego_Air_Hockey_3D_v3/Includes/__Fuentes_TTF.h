//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 31/03/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// -- Fuentes_TTF.h ------------------------------------------------------------
// -----------------------------------------------------------------------------
// #include "../Includes/Fuentes_TTF.h"
//
//    /* TTF_STYLE_NORMAL    - 0x00 - NORMAL.            */
//    /* TTF_STYLE_BOLD      - 0x01 - NEGRITA.           */
//    /* TTF_STYLE_ITALIC    - 0x02 - CURSIVA.           */
//    /* TTF_STYLE_UNDERLINE - 0x04 - SUBRAYADO.         */
//    /* TAMA�O M�XIMO DE FUENTE SOBRE 90, SEG�N FUENTE. */
//  
// int size = 14;
// c_fuente_TTF *normal    = new c_fuente_TTF( "comic.ttf", 0, size );
// c_fuente_TTF *negrita   = new c_fuente_TTF( "comic.ttf", 1, size );
// c_fuente_TTF *cursiva   = new c_fuente_TTF( "comic.ttf", 2, size );
// c_fuente_TTF *subrayado = new c_fuente_TTF( "comic.ttf", 4, size );
// c_fuente_TTF *neg_cur   = new c_fuente_TTF( "comic.ttf", 3, size );
// c_fuente_TTF *neg_sub   = new c_fuente_TTF( "comic.ttf", 5, size );
// c_fuente_TTF *cur_sub   = new c_fuente_TTF( "comic.ttf", 6, size );
// c_fuente_TTF *todos     = new c_fuente_TTF( "comic.ttf", 7, size );
//
// normal->color(      0,   0,   0 ); /* BLANCO, POR DEFECTO, DOBLE DE RAPIDO */
// negrita->color(   255,   0,   0 ); /* ROJO  */
// cursiva->color(     0, 255,   0 ); /* VERDE */
// subrayado->color(   0,   0, 255 ); /* AZUL  */
// neg_cur->color(   255, 255,   0 ); /* AMARILLO */
// neg_sub->color(     0, 255, 255 ); /* MAGENTA */
// cur_sub->color(   255,   0, 255 ); /* MORADO */
// todos->color(     255, 255, 255 ); /* NEGRO, DOBLE DE RAPIDO */
//
// int alto = normal->altura();
// int pos_x = 9, pos_y = 0;
// char texto[255];
//
// normal->escribe(    pos_x, pos_y, "Texto en estilo normal.   " );
// pos_y += alto;
// negrita->escribe(   pos_x, pos_y, "Texto en estilo negrita.  " );
// pos_y += alto;
// cursiva->escribe(   pos_x, pos_y, "Texto en estilo cursiva.  " );
// pos_y += alto;
// subrayado->escribe( pos_x, pos_y, "Texto en estilo subrayado." );
// pos_y += alto;
// neg_cur->escribe(   pos_x, pos_y, "Texto en estilo neg-cur.  " );
// pos_y += alto;
// neg_sub->escribe(   pos_x, pos_y, "Texto en estilo neg-sub.  " );
// pos_y += alto;
// cur_sub->escribe(   pos_x, pos_y, "Texto en estilo cur-sub.  " );
// pos_y += alto;
// todos->escribe(     pos_x, pos_y, "Texto en estilo todos.    " );
// 
// pos_y += alto * 3;
// pos_x += negrita->ancho_de(  "Y Dark-Alex dijo: " );
// negrita->escribe( pos_x, pos_y, "Y Dark-Alex dijo:   " );
// cursiva->escribe( pos_x, pos_y, "Lib�rense las PSP�s." );
//
// pos_x = 9;
// pos_y += alto * 3;
// /* sprintf( texto, "%s %s %d", texto_A, texto_B, numero ); */
// sprintf( texto, "Esta posici�n es X = %d, Y = %d.", pos_x, pos_y );
// negrita->color( 255, 255, 255 );
// negrita->escribe( pos_x, pos_y, texto );
// 
// pos_y += alto * 3;
// normal->escribe_b_n( 9, pos_y, "Blanco sobre Negro." );
// 
// delete normal;
// delete negrita;
// delete cursiva;
// delete subrayado;
// delete neg_cur;
// delete neg_sub;
// delete cur_sub;
// delete todos;
//
// -----------------------------------------------------------------------------
#ifndef _Fuentes_TTF_
#define _Fuentes_TTF_

// #include <iostream>
// using namespace std;
#include <GL/gl.h>										
// #include <GL/glu.h>										
#include <SDL/SDL.h>
// #include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include "Configuracion.h"
#define GL_COMPRESSED_RGB                   0x84ED

class c_fuente_TTF {
  public:
    c_fuente_TTF( const char *fuente_nombre, GLint tipo, GLint fuente_size, bool text_compresion  );
    ~c_fuente_TTF( void );
    void color( GLubyte r, GLubyte v, GLubyte a ) { rojo = r; verde = v; azul = a; }
    void escribe( GLint x, GLint y, const char *texto );
    void escribe_b_n( GLint x, GLint y, const char *texto );
    GLint ancho_de( const char *texto );
    GLint altura( void ) { return alto; }
    void ver( void );

  private:
    GLubyte letra, rojo, verde, azul;
    char texto[2];
    GLuint text_ttf, base;
    GLint estilo, alto, maxh, avance, wh, ancho_texto, minx, maxx;
    GLfloat cx, cy, c_ancho, c_alto;
    TTF_Font *fuente_TTF;
    SDL_Surface *tmp;
    SDL_Surface *tmp_texto[256];
    SDL_Rect tmp_rect;
    struct s_caracter {
      GLint ancho;  
    };
    struct s_caracter *caracter;

};

#endif
