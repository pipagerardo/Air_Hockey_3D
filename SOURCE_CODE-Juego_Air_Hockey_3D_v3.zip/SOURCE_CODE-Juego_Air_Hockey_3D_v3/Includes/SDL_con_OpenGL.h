//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 09/07/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

#ifndef _SDL_con_OpenGL_
#define _SDL_con_OpenGL_

#include <iostream>
#include <fstream>
// #include <cstdlib>
#include <string>
// #include <cmath>

#include <GL/gl.h>										
#include <GL/glu.h>										
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "Configuracion.h"
#include "Entorno.h"
#include "Mirror.h"
#include "../Includes/Sonido.h"

void Inicia_SDL_con_GL();

class c_sdl_con_opengl {
  public:
    c_sdl_con_opengl();
    ~c_sdl_con_opengl();
    void posicion_camara( GLfloat xx, GLfloat yy, GLfloat zz ) { cpx = xx; cpy = yy; cpz = zz; }
    void posicion_camara( GLfloat xx, GLfloat zz ) { cpx = xx; cpz = zz; }
    void enfoque_camara(  GLfloat xx, GLfloat yy, GLfloat zz ) { cex = xx; cey = yy; cez = zz; }
    void enfoque_camara(  GLfloat xx, GLfloat zz ) { cex = xx; cez = zz; }
    void empieza( void );
    void empieza( c_entorno *mostrar_entorno );
    void empieza_ortho_2D( void );
    void termina_ortho_2D( void );
    int dame_raton_x( void ) const { return raton_x; }
    int dame_raton_y( void ) const { return raton_y; }
    int dame_raton_xrel( void ) const { return raton_xrel; }
    int dame_raton_yrel( void ) const { return raton_yrel; }
    float dame_retardo( void ) const { return ( frames - t_espera ) * 0.001f; }
    bool termina(void);
    void toma_musica( c_musica *puntero_musica ) { musica = puntero_musica; }
    
    static SDL_Surface *pantalla;
    GLint Cube_Map_Texture_Size_Ext, Texture_Units_ARB;
    bool Texture_Cube_Map, Multitexture, Texture_Env_Combine, Texture_Env_DOT3, Texture_Compression;
    bool terminar;
    bool repetir;
    bool Mover_Camara;
    bool Pausa;

  private:
    void configuracion_3D( void );
    void leer_teclado(void);
    void espera_frame( void );
    void compatible( void );
    SDL_Event evento;           // Eventos del Teclado y Rat�n.
    Uint8 *teclado;             // Teclado
    Uint8 raton_boton;          // Rat�n
    int   raton_x;
    int   raton_y;
    int   raton_xrel;
    int   raton_yrel;
    
    Uint32 frames, tiempo, t_espera;
    GLfloat ax, ay, az;    // Rotaci�n del Cielo.
    GLfloat cpx, cpy, cpz; // Posici�n de la C�mara.
    GLfloat cex, cey, cez; // A donde mira la C�mara.
    c_musica *musica;
};

void Captura_Pantalla( const char *nombre_archivo );

#endif
