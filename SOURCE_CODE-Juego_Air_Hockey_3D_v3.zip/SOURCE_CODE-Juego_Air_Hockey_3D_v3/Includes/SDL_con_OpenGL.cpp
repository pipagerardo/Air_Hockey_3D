//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 09/07/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

#include "SDL_con_OpenGL.h"

SDL_Surface *c_sdl_con_opengl::pantalla;  // -- Variable global en una clase --

// -----------------------------------------------------------------------------
// -- Inicializar SDL con OPENGL -----------------------------------------------
// -----------------------------------------------------------------------------
void Inicia_SDL_con_GL( void ) {
  atexit( SDL_Quit );
  if( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_TIMER ) < 0 ){
    std::cerr << "No se pudo iniciar la libreria SDL: " << SDL_GetError() << std::endl;        
    exit(1);
  }
  const SDL_VideoInfo *VideoInfo = SDL_GetVideoInfo();  
  if( VideoInfo == NULL ) {
    std::cerr << "No se pudo obtener el VideoInfo: " << SDL_GetError() << std::endl;          
    exit(1);
  } 
  int P_bpp = (int)VideoInfo->vfmt->BitsPerPixel;
  if ( ( P_bpp != 16 ) && ( P_bpp != 32 ) ) P_bpp = 16;
  int VideoFlags = 0;
  VideoFlags  = SDL_OPENGL;                                         
  VideoFlags |= SDL_HWPALETTE;
  if ( !VENTANA ) VideoFlags |= SDL_FULLSCREEN;
  if (VideoInfo->hw_available) VideoFlags |= SDL_HWSURFACE;
  else                         VideoFlags |= SDL_SWSURFACE;
  SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE,   16 );
  SDL_GL_SetAttribute( SDL_GL_STENCIL_SIZE,  1 );
  SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER,  1 );
  SDL_GL_SetAttribute( SDL_GL_RED_SIZE,      5 ); // 5 -- 5 -- 8
  SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE,    6 ); // 5 -- 6 -- 8
  SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE,     5 ); // 5 -- 5 -- 8
  c_sdl_con_opengl::pantalla = SDL_SetVideoMode( V_Ancho, V_Alto, P_bpp, VideoFlags );
  if( c_sdl_con_opengl::pantalla == NULL ){
    std::cerr << "No se pudo iniciar el modo de pantalla: " << SDL_GetError() << std::endl;           
    exit(1);
  }
  SDL_WM_SetCaption( N_Ventana, NULL );    // -- Pone nombre a la ventana. --
  if ( SDL_EnableKeyRepeat( 1, SDL_DEFAULT_REPEAT_INTERVAL) )	 {
    std::cerr << "Falla activando repeticion de teclas: " << SDL_GetError() << std::endl;
    exit(1);
  }
  /*
  // -- Cargamos el Icono de la Ventana ----------------------------------------
  SDL_Surface *img_icono = IMG_Load( Nombre_Icono );
  if( !img_icono ) {
    std::cerr << "No se pudo cargar: " << Nombre_Icono << std::endl;
    exit(1);
   }
  SDL_WM_SetIcon( img_icono, NULL );
  SDL_FreeSurface( img_icono ); img_icono = NULL;
  */
}

// -----------------------------------------------------------------------------
// -- Inicializar SDL con OPENGL -----------------------------------------------
// -----------------------------------------------------------------------------
c_sdl_con_opengl::c_sdl_con_opengl( void ) {                                
  Inicia_SDL_con_GL();
  // -- Se inicia la cuenta de tiempo. -----------------------------------------
  frames = Uint32( 1000 / FOTOGRAMAS );
  tiempo = SDL_GetTicks() + frames;
  // -- Inicializa la semilla de numeros aleatorios. ---------------------------
  srand(time(0));
  terminar = false;
  repetir = false;
  Pausa = false;
  Mover_Camara = false;
  ax = 0.0f; ay = 0.0f; az = 0.0f;
  cpx = 0.0f; cpy = 0.0f; cpz = 4.0f;
  cex = 0.0f; cey = 0.0f; cez = 0.0f;
  Cube_Map_Texture_Size_Ext = 0;
  Texture_Units_ARB   = 0;
  Texture_Cube_Map    = false;
  Multitexture        = false;
  Texture_Env_DOT3    = false;
  Texture_Env_Combine = false;
  Texture_Compression = false;
  this->compatible();
  this->configuracion_3D();
}

// -----------------------------------------------------------------------------
// -- Cerar SDL ----------------------------------------------------------------
// -----------------------------------------------------------------------------
c_sdl_con_opengl::~c_sdl_con_opengl( void ) {
  SDL_FreeSurface( pantalla );          // -- Liberar memoria pantalla --
  pantalla = NULL;
  SDL_Quit();                           // -- Cerrar SDL --
}	

// -----------------------------------------------------------------------------
// -- Configuraci�n del entorno 3D ---------------------------------------------
// -----------------------------------------------------------------------------
void c_sdl_con_opengl::configuracion_3D( void ) {
  glClearColor( RF, GF, BF, AF );    // Borrado del Buffer Color.
  glClearDepth( 1.0f );              // Borrado del Buffer Depth
  glDepthFunc( GL_LEQUAL );          // Funci�n de Borrado Buffer Depth      
  glEnable ( GL_DEPTH_TEST );        // Activamos el Test de Profundidad.
  glClearStencil( 0 );               // Borrado del Buffer Stencil
  glFrontFace( GL_CCW );             // GL_CCW   o GL_CW.
  glCullFace( GL_BACK );             // GL_FRONT o GL_BACK.
  glEnable( GL_CULL_FACE );          // NO DIBUJA LAS CARAS TRASERAS
  glShadeModel( GL_SMOOTH );         // Activamos el Sombreado Suave, (GL_FLAT) Plano.
  glPolygonMode( GL_FRONT_AND_BACK, GL_FILL); //  GL_FILL, GL_LINE y GL_POINT
  glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );
  glViewport( 0, 0, V_Ancho, V_Alto ); // Define la Ventana de visualizado.
  glMatrixMode(GL_PROJECTION);         // Selecciona la Matriz de Proyecci�n.
  glLoadIdentity();                    // Reemplaza la matriz. 
  gluPerspective( 45.0f, (GLfloat)V_Ancho/(GLfloat)V_Alto, .5f , -1000.0f );
  glMatrixMode(GL_MODELVIEW);          // Selecciona la Matriz de Modelado.               
  glLoadIdentity();                    // Reemplaza la matriz.
  // Configuraci�n de Transparencias -------------------------------------------
  glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
  glAlphaFunc( GL_ALWAYS, 1.0);
  // glAlphaFunc( GL_GREATER, 0.5f );
  // -- CONFIGURACI�N DE VISUALIZACION -----------------------------------------
  glDisable( GL_COLOR_MATERIAL );   // ACTIVA glMaterialfv();
  glEnable(  GL_CULL_FACE );        // ACTIVA OCULTAR CARAS TRASERAS
  glDisable( GL_FOG );              // DESACTIVA LA NIEBLA
  glEnable(  GL_LIGHTING );         // ACTIVA LA LUZ
  glEnable( GL_LIGHT0 );            // ACTIVA LA LUZ N� 0
}

// -----------------------------------------------------------------------------
// -- c_sdl_con_opengl.empieza(); ----------------------------------------------
// -----------------------------------------------------------------------------
void c_sdl_con_opengl::empieza(void) {
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
  glLoadIdentity();
  gluLookAt( cpx, cpy, cpz, cex, cey, cez, 0.0f, 1.0f, 0.0f );
  glRotatef( ax, 1.0f, 0.0f, 0.0f );
  glRotatef( ay, 0.0f, 1.0f, 0.0f );
  glRotatef( az, 0.0f, 0.0f, 1.0f );
}

// -----------------------------------------------------------------------------
// -- c_sdl_con_opengl.empieza( c_entorno *mostrar_entorno ); ------------------
// -----------------------------------------------------------------------------
void c_sdl_con_opengl::empieza( c_entorno *mostrar_entorno ) {
  glClear( GL_DEPTH_BUFFER_BIT );
  glLoadIdentity();
  gluLookAt( cpx, cpy, cpz, cex, cey, cez, 0.0f, 1.0f, 0.0f );
  glRotatef( ax, 1.0f, 0.0f, 0.0f );
  glRotatef( ay, 0.0f, 1.0f, 0.0f );
  glRotatef( az, 0.0f, 0.0f, 1.0f );
  mostrar_entorno->mostrar();
}

// -----------------------------------------------------------------------------
// -- c_sdl_con_opengl.termina(); ----------------------------------------------
// -----------------------------------------------------------------------------
bool c_sdl_con_opengl::termina(void) {
  do {
  this->leer_teclado();	
  this->espera_frame();
  } while ( Pausa && !terminar );
  SDL_GL_SwapBuffers();
  return terminar;
}

// -----------------------------------------------------------------------------
// -- Leer el Teclado ----------------------------------------------------------
// -----------------------------------------------------------------------------
void c_sdl_con_opengl::leer_teclado(void) {
  while(SDL_PollEvent(&evento))   {   // -- Consultamos los eventos --
    switch( evento.type ) {
      case SDL_QUIT: terminar = true; repetir = false; break; 
      case SDL_ACTIVEEVENT:
        if(evento.active.gain == 0) {
          Pausa = true;
          if ( MUSICA ) musica->pausa();
          SDL_ShowCursor( SDL_ENABLE );
          SDL_WM_GrabInput( SDL_GRAB_OFF );
        } else {
          Pausa = false;
          if ( MUSICA ) musica->reanuda();
          SDL_ShowCursor( SDL_DISABLE );
          SDL_WM_GrabInput( SDL_GRAB_ON );
          SDL_WarpMouse( V_Ancho >> 1, Uint16( V_Alto / 1.5f ) );
        } break;
      case SDL_KEYDOWN:  
        if(evento.key.keysym.sym == SDLK_ESCAPE ) terminar = true; break;
      case SDL_MOUSEBUTTONDOWN:
        if ( Mover_Camara ) {
          switch( evento.button.button ){
            case SDL_BUTTON_WHEELUP:   cpy -= 0.2f; break;
            case SDL_BUTTON_WHEELDOWN: cpy += 0.2f; break;
          }
        }
      break; 
    }
  }
  SDL_PumpEvents();
  teclado     = SDL_GetKeyState(NULL);
  raton_boton = SDL_GetMouseState( &raton_x, &raton_y );
  raton_y = V_Alto - raton_y - 1;
  SDL_GetRelativeMouseState( &raton_xrel, &raton_yrel );
  //-- ROTAR Y MOVER LA CAMARA CON EL RATON --
  if ( Mover_Camara ) {
    if ( raton_boton == 1 ) {  //-- BOTON IZQUIERDO RATON --
      ay += raton_xrel / 8.0f; 
      ax += raton_yrel / 8.0f; 
      if ( ay > 360.0f ) ay -= 360.0f;
      if ( ay < 0.0f   ) ay += 360.0f;
      if ( ax > 360.0f ) ax -= 360.0f;
      if ( ax < 0.0f   ) ax += 360.0f;
    }
    //-- BOTON DERECHO RATON --
    if ( raton_boton == 4 ) cpy += raton_yrel / 8.0f;  
  }
  if ( teclado[SDLK_RETURN] || teclado[SDLK_SPACE] ) { terminar = true; repetir = true; }
  if ( teclado[T_P] || teclado[SDLK_PAUSE] ) {
    if ( Pausa == true ) {
      Pausa = false;
      if ( MUSICA ) musica->reanuda();
      SDL_ShowCursor( SDL_DISABLE );
      SDL_WM_GrabInput( SDL_GRAB_ON );
      SDL_WarpMouse( V_Ancho >> 1, Uint16( V_Alto / 1.5f ) );
    } else {                 
      Pausa = true;
      if ( MUSICA ) musica->pausa();
      SDL_ShowCursor( SDL_ENABLE );
      SDL_WM_GrabInput( SDL_GRAB_OFF );
    }
    SDL_Delay( 300 ); this->espera_frame();
  }
  if ( teclado[T_M] ) {
    if ( MUSICA ) {
      if ( musica->esta_sonando() == 1 ) musica->para();
      else                               musica->reproduce();
      SDL_Delay( 300 ); this->espera_frame();
    }
  }
  if ( teclado[T_Cursor] ) {
    if ( SDL_ShowCursor( SDL_QUERY ) ==  SDL_ENABLE ) SDL_ShowCursor( SDL_DISABLE );
    else                                              SDL_ShowCursor( SDL_ENABLE );
    SDL_Delay( 300 ); this->espera_frame();
  }
  if (teclado[T_MC]) {
    if ( Mover_Camara == true ) Mover_Camara = false;
    else                        Mover_Camara = true;
    SDL_Delay( 300 );  this->espera_frame();
  }
  
}

// -----------------------------------------------------------------------------
// -- Esperar al frame ---------------------------------------------------------
// -----------------------------------------------------------------------------
void c_sdl_con_opengl::espera_frame( void ) {
  t_espera = tiempo - SDL_GetTicks();
  if ( ( t_espera > 0 ) && ( t_espera < frames ) ) SDL_Delay( t_espera );
  else tiempo = SDL_GetTicks();
  tiempo += frames;
}

// -----------------------------------------------------------------------------
// -- Empieza_ortho_2D() -------------------------------------------------------
// -----------------------------------------------------------------------------
void c_sdl_con_opengl::empieza_ortho_2D( void ) { 
  glEnable( GL_COLOR_MATERIAL );
  glDisable( GL_LIGHTING );
  glMatrixMode( GL_PROJECTION );
  glPushMatrix( );               // -- Guarda la Matriz de Proyecci�n --
  glLoadIdentity( );
  glOrtho( 0, V_Ancho, 0, V_Alto, -1, 1 ); // -- Cambia a modo ortog�fico --
  glMatrixMode( GL_MODELVIEW );
  glPushMatrix( );              // -- Guarda la Matriz de Modelado --
  glLoadIdentity( );
  glEnable( GL_TEXTURE_2D );
  glDisable( GL_DEPTH_TEST );
}

// -----------------------------------------------------------------------------
// -- Termina_ortho_2D() -------------------------------------------------------
// -----------------------------------------------------------------------------
void c_sdl_con_opengl::termina_ortho_2D( void ) {
  glEnable( GL_DEPTH_TEST );
  glDisable( GL_TEXTURE_2D ); 
  glMatrixMode( GL_PROJECTION );
  glPopMatrix( );                // -- Restaura la Matriz de Proyecci�n --
  glMatrixMode( GL_MODELVIEW );
  glPopMatrix( );                // -- Restaura la Matriz de Modelado --
  glDisable( GL_COLOR_MATERIAL );
  glEnable(  GL_LIGHTING );   
}

// -----------------------------------------------------------------------------
// -- Compatibilidad de las Extensiones de la Tarjeta Gr�fica ------------------
// -----------------------------------------------------------------------------
void c_sdl_con_opengl::compatible( void ) {
  std::ofstream tarjeta_grafica_EXT;
  if ( EXTENSIONES ) tarjeta_grafica_EXT.open("tarjeta_grafica_EXT.txt", std::ios::out );
  const GLubyte* glExtensions = glGetString( GL_EXTENSIONS ); 
  int i;
  for ( i = 0; glExtensions[i] != '\0'; i++ );
  char *Extensiones = new char[i + 1];
  for ( i = 0; glExtensions[i] != '\0'; i++ ) Extensiones[i] =  char( glExtensions[i] );
  Extensiones[i] = '\0';
  #define GL_MAX_CUBE_MAP_TEXTURE_SIZE_EXT  0x851C
  #define GL_MAX_TEXTURE_UNITS_ARB          0x84E2
  glGetIntegerv( GL_MAX_CUBE_MAP_TEXTURE_SIZE_EXT, &Cube_Map_Texture_Size_Ext ); 
  glGetIntegerv( GL_MAX_TEXTURE_UNITS_ARB,         &Texture_Units_ARB );
  char *p = strtok( Extensiones, " " );
  if( p ) { 
    if ( EXTENSIONES ) tarjeta_grafica_EXT << p << std::endl; 
    if ( strcmp( p, "GL_ARB_texture_cube_map" )    == 0 ) Texture_Cube_Map    = true;
    if ( strcmp( p, "GL_ARB_multitexture" )        == 0 ) Multitexture        = true; 
    if ( strcmp( p, "GL_ARB_texture_env_combine" ) == 0 ) Texture_Env_Combine = true; 
    if ( strcmp( p, "GL_ARB_texture_env_dot3" )    == 0 ) Texture_Env_DOT3    = true;
    if ( strcmp( p, "GL_ARB_texture_compression")  == 0 ) Texture_Compression = true;
  }
  while( p ) {
    p = strtok( NULL, " " );
    if( p ) { 
      if ( EXTENSIONES ) tarjeta_grafica_EXT << p << std::endl; 
      if ( strcmp( p, "GL_ARB_texture_cube_map" )    == 0 ) Texture_Cube_Map    = true;
      if ( strcmp( p, "GL_ARB_multitexture" )        == 0 ) Multitexture        = true;
      if ( strcmp( p, "GL_ARB_texture_env_combine" ) == 0 ) Texture_Env_Combine = true;
      if ( strcmp( p, "GL_ARB_texture_env_dot3" )    == 0 ) Texture_Env_DOT3    = true;
      if ( strcmp( p, "GL_ARB_texture_compression")  == 0 ) Texture_Compression = true;
    }
  }
  delete[] Extensiones;
  if ( EXTENSIONES ) tarjeta_grafica_EXT.close();
}

// -----------------------------------------------------------------------------
// -- FUNCION QUE CAPTURA LA PANTALLA ------------------------------------------
// -----------------------------------------------------------------------------
void Captura_Pantalla( const char *nombre_archivo ) {
  SDL_Surface *tmp;
  GLint viewport[4];		/* Vista actual */
  glGetIntegerv( GL_VIEWPORT, viewport );
  #if SDL_BYTEORDER == SDL_BIG_ENDIAN
    tmp = SDL_CreateRGBSurface( SDL_SWSURFACE, viewport[2], viewport[3], 24, 0xff0000, 0x00ff00, 0x0000ff, 0x000000 );
  #else
    tmp = SDL_CreateRGBSurface( SDL_SWSURFACE, viewport[2], viewport[3], 24, 0x0000ff, 0x00ff00, 0xff0000, 0x000000 );
  #endif
  glPixelStorei( GL_PACK_ALIGNMENT,   4 );
  glPixelStorei( GL_PACK_ROW_LENGTH,  0 );
  glPixelStorei( GL_PACK_SKIP_ROWS,   0 );
  glPixelStorei( GL_PACK_SKIP_PIXELS, 0 );
  glCopyPixels( 0, 0, viewport[2], viewport[3], GL_COLOR );
  glReadPixels( 0, 0, viewport[2], viewport[3], GL_RGB, GL_UNSIGNED_BYTE, tmp->pixels );
  tmp = MirrorSurfaceX( tmp ); // -- La imagen es invertida en el eje X --
  SDL_SaveBMP( tmp, nombre_archivo );
  SDL_FreeSurface( tmp ); tmp = NULL;
}
