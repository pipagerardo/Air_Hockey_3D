//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 31/03/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

#include "Figuras.h"

// -------------------------------------------------------------------------
// Dibuja un Pol�gono, m�nimo 3 caras, con normales planas o suavizadas.
// -------------------------------------------------------------------------
void Dibuja_Poligono( GLfloat radio, GLint caras, bool suavizado ) {
  GLfloat x_aux = 0.0f, y_aux = 0.0f, z_aux = 0.0f;
  GLfloat x_nor = 0.0f, y_nor = 0.0f, z_nor = 0.0f;
  if ( caras < 3 ) caras = 3; else if ( caras > 128 ) caras = 128;
  GLfloat modulo = 0.0f, inc = PI2/caras;
  glBegin(GL_POLYGON);
    for ( GLfloat angulo = PI2;  angulo > 0.0f; angulo -= inc ) {
      x_aux =   GLfloat(radio * sin(angulo));
      y_aux   = GLfloat(radio * cos(angulo));
      if ( suavizado ) {
        modulo = (GLfloat) sqrt( (x_aux * x_aux  ) + (y_aux * y_aux) + 1 );
        x_nor = x_aux/ modulo; y_nor = y_aux/ modulo; z_nor = 1.0f / modulo;
        glNormal3f( x_nor, y_nor, z_nor );
      } else glNormal3f(  0.0f,  0.0f,  1.0f );
      glTexCoord2f( 0.5f+(GLfloat(sin(angulo))/2.0f), 0.5f+(GLfloat(cos(angulo))/2.0f));
      glVertex3f( x_aux, y_aux, z_aux );
    }  
  glEnd();
}

// -------------------------------------------------------------------------
// Dibuja un Cubo sin Textura de Coordenadas.
// -------------------------------------------------------------------------
void Dibuja_Cubo( GLfloat bx, GLfloat by, GLfloat bz, bool suavizado ) {
  GLfloat Vertex_Cubo[] = {
    -bx,  by, -bz,  bx,  by, -bz,  bx, -by, -bz, -bx, -by, -bz, // FONDO
     bx, -by,  bz, -bx, -by,  bz, -bx, -by, -bz,  bx, -by, -bz, // ABAJO
     bx,  by, -bz,  bx,  by,  bz,  bx, -by,  bz,  bx, -by, -bz, // DERECHA
    -bx,  by,  bz, -bx,  by, -bz, -bx, -by, -bz, -bx, -by,  bz, // IZQUIERDA    
     bx,  by, -bz, -bx,  by, -bz, -bx,  by,  bz,  bx,  by,  bz, // ARRIBA    
     bx,  by,  bz, -bx,  by,  bz, -bx, -by,  bz,  bx, -by,  bz  // FRENTE  
    }; 
  GLfloat *Normal_Cubo = new GLfloat[72];
  Calcula_Normales_4( Vertex_Cubo, Normal_Cubo, 72 );
  if ( suavizado ) Suavizado_Normales( Vertex_Cubo, Normal_Cubo, 72 );
  glEnableClientState( GL_NORMAL_ARRAY ); 
  glEnableClientState( GL_VERTEX_ARRAY );
    glNormalPointer( GL_FLOAT, 0, Normal_Cubo );
    glVertexPointer( 3, GL_FLOAT, 0, Vertex_Cubo );
    glDrawArrays( GL_QUADS, 0, 24 ); 
  glDisableClientState( GL_NORMAL_ARRAY );
  glDisableClientState( GL_VERTEX_ARRAY );
  delete[] Normal_Cubo;
}

// -------------------------------------------------------------------------
// Dibuja un Cubo con Textura de Coordenadas Tipo 1.
// -------------------------------------------------------------------------
void Dibuja_Cubo_T1( GLfloat bx, GLfloat by, GLfloat bz, bool suavizado ) {
  GLfloat Texcoord_Cubo[] = { 
    1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // FONDO
    1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // ABAJO
    1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // DERECHA
    1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // IZQUIERDA
    1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // ARRIBA
    1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f  // FRENTE
  };
  GLfloat Vertex_Cubo[] = {
    -bx,  by, -bz,  bx,  by, -bz,  bx, -by, -bz, -bx, -by, -bz, // FONDO
     bx, -by,  bz, -bx, -by,  bz, -bx, -by, -bz,  bx, -by, -bz, // ABAJO
     bx,  by, -bz,  bx,  by,  bz,  bx, -by,  bz,  bx, -by, -bz, // DERECHA
    -bx,  by,  bz, -bx,  by, -bz, -bx, -by, -bz, -bx, -by,  bz, // IZQUIERDA    
     bx,  by, -bz, -bx,  by, -bz, -bx,  by,  bz,  bx,  by,  bz, // ARRIBA    
     bx,  by,  bz, -bx,  by,  bz, -bx, -by,  bz,  bx, -by,  bz  // FRENTE  
    }; 
  GLfloat *Normal_Cubo = new GLfloat[72];
  Calcula_Normales_4( Vertex_Cubo, Normal_Cubo, 72 );
  if ( suavizado ) Suavizado_Normales( Vertex_Cubo, Normal_Cubo, 72 );
  glEnableClientState( GL_NORMAL_ARRAY ); 
  glEnableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glEnableClientState( GL_VERTEX_ARRAY );
    glNormalPointer( GL_FLOAT, 0, Normal_Cubo );
    glTexCoordPointer( 2, GL_FLOAT, 0, Texcoord_Cubo );
    glVertexPointer( 3, GL_FLOAT, 0, Vertex_Cubo );
    glDrawArrays( GL_QUADS, 0, 24 ); 
  glDisableClientState( GL_NORMAL_ARRAY );
  glDisableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glDisableClientState( GL_VERTEX_ARRAY );
  delete[] Normal_Cubo;
}

// -------------------------------------------------------------------------
// Dibuja un Cubo con Textura de Coordenadas Tipo 2.
// -------------------------------------------------------------------------
void Dibuja_Cubo_T2( GLfloat bx, GLfloat by, GLfloat bz, bool suavizado ) {
  GLfloat Texcoord_Cubo[] = { 
    0.33333f, 1.0f, 0.00000f, 1.0f, 0.00000f, 0.5f, 0.33333f, 0.5f, // FONDO
    1.00000f, 1.0f, 0.66666f, 1.0f, 0.66666f, 0.5f, 1.00000f, 0.5f, // ABAJO
    1.00000f, 0.5f, 0.66666f, 0.5f, 0.66666f, 0.0f, 1.00000f, 0.0f, // DERECHA
    0.33333f, 0.5f, 0.00000f, 0.5f, 0.00000f, 0.0f, 0.33333f, 0.0f, // IZQUIERDA
    0.66666f, 1.0f, 0.33333f, 1.0f, 0.33333f, 0.5f, 0.66666f, 0.5f, // ARRIBA
    0.66666f, 0.5f, 0.33333f, 0.5f, 0.33333f, 0.0f, 0.66666f, 0.0f  // FRENTE
  };
  GLfloat Vertex_Cubo[] = {
    -bx,  by, -bz,  bx,  by, -bz,  bx, -by, -bz, -bx, -by, -bz, // FONDO
     bx, -by,  bz, -bx, -by,  bz, -bx, -by, -bz,  bx, -by, -bz, // ABAJO
     bx,  by, -bz,  bx,  by,  bz,  bx, -by,  bz,  bx, -by, -bz, // DERECHA
    -bx,  by,  bz, -bx,  by, -bz, -bx, -by, -bz, -bx, -by,  bz, // IZQUIERDA    
     bx,  by, -bz, -bx,  by, -bz, -bx,  by,  bz,  bx,  by,  bz, // ARRIBA    
     bx,  by,  bz, -bx,  by,  bz, -bx, -by,  bz,  bx, -by,  bz  // FRENTE  
    }; 
  GLfloat *Normal_Cubo = new GLfloat[72];
  Calcula_Normales_4( Vertex_Cubo, Normal_Cubo, 72 );
  if ( suavizado ) Suavizado_Normales( Vertex_Cubo, Normal_Cubo, 72 );
  glEnableClientState( GL_NORMAL_ARRAY ); 
  glEnableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glEnableClientState( GL_VERTEX_ARRAY );
    glNormalPointer( GL_FLOAT, 0, Normal_Cubo );
    glTexCoordPointer( 2, GL_FLOAT, 0, Texcoord_Cubo );
    glVertexPointer( 3, GL_FLOAT, 0, Vertex_Cubo );
    glDrawArrays( GL_QUADS, 0, 24 ); 
  glDisableClientState( GL_NORMAL_ARRAY );
  glDisableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glDisableClientState( GL_VERTEX_ARRAY );
  delete[] Normal_Cubo;
}

// -------------------------------------------------------------------------
// Dibuja un Cubo con Textura de Coordenadas Tipo 3.
// -------------------------------------------------------------------------
void Dibuja_Cubo_T3( GLfloat bx, GLfloat by, GLfloat bz, bool suavizado ) {
  GLfloat Texcoord_Cubo[] = { 
    1.00f, 0.66666f, 0.75f, 0.66666f, 0.75f, 0.33333f, 1.00f, 0.33333f, // FONDO
    0.50f, 0.33333f, 0.25f, 0.33333f, 0.25f, 0.00000f, 0.50f, 0.00000f, // ABAJO
    0.75f, 0.66666f, 0.50f, 0.66666f, 0.50f, 0.33333f, 0.75f, 0.33333f, // DERECHA
    0.25f, 0.66666f, 0.00f, 0.66666f, 0.00f, 0.33333f, 0.25f, 0.33333f, // IZQUIERDA
    0.50f, 1.00000f, 0.25f, 1.00000f, 0.25f, 0.66666f, 0.50f, 0.66666f, // ARRIBA
    0.50f, 0.66666f, 0.25f, 0.66666f, 0.25f, 0.33333f, 0.50f, 0.33333f  // FRENTE
  };
  GLfloat Vertex_Cubo[] = {
    -bx,  by, -bz,  bx,  by, -bz,  bx, -by, -bz, -bx, -by, -bz, // FONDO
     bx, -by,  bz, -bx, -by,  bz, -bx, -by, -bz,  bx, -by, -bz, // ABAJO
     bx,  by, -bz,  bx,  by,  bz,  bx, -by,  bz,  bx, -by, -bz, // DERECHA
    -bx,  by,  bz, -bx,  by, -bz, -bx, -by, -bz, -bx, -by,  bz, // IZQUIERDA    
     bx,  by, -bz, -bx,  by, -bz, -bx,  by,  bz,  bx,  by,  bz, // ARRIBA    
     bx,  by,  bz, -bx,  by,  bz, -bx, -by,  bz,  bx, -by,  bz  // FRENTE  
    }; 
  GLfloat *Normal_Cubo = new GLfloat[72];
  Calcula_Normales_4( Vertex_Cubo, Normal_Cubo, 72 );
  if ( suavizado ) Suavizado_Normales( Vertex_Cubo, Normal_Cubo, 72 );
  glEnableClientState( GL_NORMAL_ARRAY ); 
  glEnableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glEnableClientState( GL_VERTEX_ARRAY );
    glNormalPointer( GL_FLOAT, 0, Normal_Cubo );
    glTexCoordPointer( 2, GL_FLOAT, 0, Texcoord_Cubo );
    glVertexPointer( 3, GL_FLOAT, 0, Vertex_Cubo );
    glDrawArrays( GL_QUADS, 0, 24 ); 
  glDisableClientState( GL_NORMAL_ARRAY );
  glDisableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glDisableClientState( GL_VERTEX_ARRAY );
  delete[] Normal_Cubo;
}

// -------------------------------------------------------------------------
// Dibuja una Pir�mide y calcula las normales que dependen de la altura/base
// -------------------------------------------------------------------------
void Dibuja_Piramide( GLfloat bx, GLfloat by, GLfloat bz, bool suavizado ) {
  GLfloat Vertex_Piramide[] = { 
    0.0f, by, 0.0f,  bx, -by, -bz, -bx, -by, -bz, // CARA TRASERA
    -bx, -by,   bz, -bx, -by, -bz,  bx, -by, -bz, // BASE
     bx, -by,  -bz,  bx, -by,  bz, -bx, -by,  bz, // BASE
    0.0f, by, 0.0f,  bx, -by,  bz,  bx, -by, -bz, // CARA DERECHA
    0.0f, by, 0.0f, -bx, -by, -bz, -bx, -by,  bz, // CARA IZQUIERDA
    0.0f, by, 0.0f, -bx, -by,  bz,  bx, -by,  bz  // CARA FRONTAL
  };
  GLfloat *Normal_Piramide = new GLfloat[ 54 ];
  Calcula_Normales_3( Vertex_Piramide, Normal_Piramide, 54 );
  if ( suavizado ) Suavizado_Normales( Vertex_Piramide, Normal_Piramide, 54 );
  glEnableClientState( GL_NORMAL_ARRAY ); 
  glEnableClientState( GL_VERTEX_ARRAY );
    glNormalPointer( GL_FLOAT, 0, Normal_Piramide );
    glVertexPointer( 3, GL_FLOAT, 0, Vertex_Piramide );
    glDrawArrays( GL_TRIANGLES, 0, 18 ); 
  glDisableClientState( GL_NORMAL_ARRAY );
  glDisableClientState( GL_VERTEX_ARRAY );
  delete[] Normal_Piramide;
}

// -------------------------------------------------------------------------
// Dibuja una Pir�mide con Textura de Coordenadas Tipo 1.
// -------------------------------------------------------------------------
void Dibuja_Piramide_T1( GLfloat bx, GLfloat by, GLfloat bz, bool suavizado ) {
  GLfloat Texcoord_Piramide[] = {
    0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // CARA TRASERA
    0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // BASE 
    1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, // BASE
    0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // CARA DERECHA
    0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // CARA IZQUIERDA 
    0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f  // CARA FRONTAL
  };
  GLfloat Vertex_Piramide[] = { 
    0.0f, by, 0.0f,  bx, -by, -bz, -bx, -by, -bz, // CARA TRASERA
    -bx, -by,   bz, -bx, -by, -bz,  bx, -by, -bz, // BASE
     bx, -by,  -bz,  bx, -by,  bz, -bx, -by,  bz, // BASE
    0.0f, by, 0.0f,  bx, -by,  bz,  bx, -by, -bz, // CARA DERECHA
    0.0f, by, 0.0f, -bx, -by, -bz, -bx, -by,  bz, // CARA IZQUIERDA
    0.0f, by, 0.0f, -bx, -by,  bz,  bx, -by,  bz  // CARA FRONTAL
  };
  GLfloat *Normal_Piramide = new GLfloat[ 54 ];
  Calcula_Normales_3( Vertex_Piramide, Normal_Piramide, 54 );
  if ( suavizado ) Suavizado_Normales( Vertex_Piramide, Normal_Piramide, 54 );
  glEnableClientState( GL_NORMAL_ARRAY ); 
  glEnableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glEnableClientState( GL_VERTEX_ARRAY );
    glNormalPointer( GL_FLOAT, 0, Normal_Piramide );
    glTexCoordPointer( 2, GL_FLOAT, 0, Texcoord_Piramide );
    glVertexPointer( 3, GL_FLOAT, 0, Vertex_Piramide );
    glDrawArrays( GL_TRIANGLES, 0, 18 ); 
  glDisableClientState( GL_NORMAL_ARRAY );
  glDisableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glDisableClientState( GL_VERTEX_ARRAY );
  delete[] Normal_Piramide;
}

// -------------------------------------------------------------------------
// Dibuja una Pir�mide con Textura de Coordenadas Tipo 2.
// -------------------------------------------------------------------------
void Dibuja_Piramide_T2( GLfloat bx, GLfloat by, GLfloat bz, bool suavizado ) {
  GLfloat Texcoord_Piramide[] = {
    0.875f, 1.0f, 0.75f, 0.5f, 1.00f, 0.5f, // CARA TRASERA
    0.25f,  0.5f, 0.25f, 0.0f, 0.50f, 0.0f, // BASE 
    0.50f,  0.0f, 0.50f, 0.5f, 0.25f, 0.5f, // BASE
    0.625f, 1.0f, 0.50f, 0.5f, 0.75f, 0.5f, // CARA DERECHA
    0.125f, 1.0f, 0.00f, 0.5f, 0.25f, 0.5f, // CARA IZQUIERDA 
    0.375f, 1.0f, 0.25f, 0.5f, 0.50f, 0.5f  // CARA FRONTAL
  };
  GLfloat Vertex_Piramide[] = { 
    0.0f, by, 0.0f,  bx, -by, -bz, -bx, -by, -bz, // CARA TRASERA
    -bx, -by,   bz, -bx, -by, -bz,  bx, -by, -bz, // BASE
     bx, -by,  -bz,  bx, -by,  bz, -bx, -by,  bz, // BASE
    0.0f, by, 0.0f,  bx, -by,  bz,  bx, -by, -bz, // CARA DERECHA
    0.0f, by, 0.0f, -bx, -by, -bz, -bx, -by,  bz, // CARA IZQUIERDA
    0.0f, by, 0.0f, -bx, -by,  bz,  bx, -by,  bz  // CARA FRONTAL
  };
  GLfloat *Normal_Piramide = new GLfloat[ 54 ];
  Calcula_Normales_3( Vertex_Piramide, Normal_Piramide, 54 );
  if ( suavizado ) Suavizado_Normales( Vertex_Piramide, Normal_Piramide, 54 );
  glEnableClientState( GL_NORMAL_ARRAY ); 
  glEnableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glEnableClientState( GL_VERTEX_ARRAY );
    glNormalPointer( GL_FLOAT, 0, Normal_Piramide );
    glTexCoordPointer( 2, GL_FLOAT, 0, Texcoord_Piramide );
    glVertexPointer( 3, GL_FLOAT, 0, Vertex_Piramide );
    glDrawArrays( GL_TRIANGLES, 0, 18 ); 
  glDisableClientState( GL_NORMAL_ARRAY );
  glDisableClientState( GL_TEXTURE_COORD_ARRAY ); 
  glDisableClientState( GL_VERTEX_ARRAY );
  delete[] Normal_Piramide;
}

// -------------------------------------------------------------------------
// Dibuja una Esfera usando gluQuadric
// -------------------------------------------------------------------------
void Dibuja_Esfera( GLfloat radio, GLint segmentos, bool suavizado ) {
  GLUquadricObj *qobj = gluNewQuadric();
  gluQuadricDrawStyle(   qobj, GLU_FILL );
  gluQuadricOrientation( qobj, GLU_OUTSIDE );
  if ( suavizado ) { glShadeModel( GL_SMOOTH ); gluQuadricNormals( qobj, GLU_SMOOTH ); }
  else             { glShadeModel( GL_FLAT );   gluQuadricNormals( qobj, GLU_FLAT   ); } 
  gluQuadricTexture(     qobj, GL_TRUE  );
  glPushMatrix();
  glRotatef( -90, 1.0f, 0.0f, 0.0f );
  gluSphere( qobj, radio, segmentos, segmentos ); 
  glPopMatrix();
  gluDeleteQuadric( qobj );
  glShadeModel( GL_SMOOTH );
}

// -------------------------------------------------------------------------
// Dibuja una Esfera Achatada usando gluQuadric
// -------------------------------------------------------------------------
void Dibuja_Esfera_Achatada( GLfloat rx, GLfloat ry, GLfloat rz, GLint segmentos, bool suavizado ) {
  glEnable( GL_NORMALIZE );
  glPushMatrix();
  glScalef( 1.0f, ry/rx, rz/rx );
  Dibuja_Esfera( rx, segmentos, suavizado );
  glPopMatrix();
  glDisable( GL_NORMALIZE );
}

// -------------------------------------------------------------------------
// Dibuja un Cono usando gluQuadric
// -------------------------------------------------------------------------
void Dibuja_Cono( GLfloat radio, GLfloat altura, GLint segmentos, bool suavizado ) {
  GLUquadricObj *qobj = gluNewQuadric();
  gluQuadricDrawStyle(   qobj, GLU_FILL );
  gluQuadricOrientation( qobj, GLU_OUTSIDE ); 
  if ( suavizado ) { glShadeModel( GL_SMOOTH ); gluQuadricNormals( qobj, GLU_SMOOTH ); }
  else             { glShadeModel( GL_FLAT );   gluQuadricNormals( qobj, GLU_FLAT   ); } 
  gluQuadricTexture(     qobj, GL_TRUE  );
  glPushMatrix();
  glRotatef(  90, 1.0f, 0.0f, 0.0f );
  // glRotatef( 180, 0.0f, 0.0f, 1.0f );
  glTranslatef( 0.0f, 0.0f, -altura/2.0f );
  gluCylinder( qobj, 0.0f, radio, altura, segmentos, 1 );
  glTranslatef( 0.0f, 0.0f, altura );
  gluDisk( qobj, 0.0f, radio, segmentos, 1 );
  glPopMatrix();
  gluDeleteQuadric( qobj );
  glShadeModel( GL_SMOOTH );
}

// -------------------------------------------------------------------------
// Dibuja una Tubo usando gluQuadric
// -------------------------------------------------------------------------
void Dibuja_Tubo( GLfloat r_inf, GLfloat r_sup, GLfloat altura, GLint segmentos, bool suavizado ) {
  GLUquadricObj *qobj = gluNewQuadric();
  gluQuadricDrawStyle(   qobj, GLU_FILL );
  gluQuadricOrientation( qobj, GLU_OUTSIDE ); 
  if ( suavizado ) { glShadeModel( GL_SMOOTH ); gluQuadricNormals( qobj, GLU_SMOOTH ); }
  else             { glShadeModel( GL_FLAT );   gluQuadricNormals( qobj, GLU_FLAT   ); } 
  gluQuadricTexture(     qobj, GL_TRUE  );
  glPushMatrix();
  glRotatef( -90, 1.0f, 0.0f, 0.0f );
  glTranslatef( 0.0f, 0.0f, -altura/2.0f );
  gluCylinder( qobj, r_sup, r_inf, altura, segmentos, 1 );
  glPopMatrix();
  gluDeleteQuadric( qobj );
  glShadeModel( GL_SMOOTH );
}

// -------------------------------------------------------------------------
// Dibuja un Cilindro usando gluQuadric
// -------------------------------------------------------------------------
void Dibuja_Cilindro( GLfloat r_inf, GLfloat r_sup, GLfloat altura, GLint segmentos, bool suavizado ) {
  GLUquadricObj *qobj = gluNewQuadric();
  gluQuadricDrawStyle(   qobj, GLU_FILL );
  gluQuadricOrientation( qobj, GLU_OUTSIDE ); 
  if ( suavizado ) { glShadeModel( GL_SMOOTH ); gluQuadricNormals( qobj, GLU_SMOOTH ); }
  else             { glShadeModel( GL_FLAT );   gluQuadricNormals( qobj, GLU_FLAT   ); } 
  gluQuadricTexture(     qobj, GL_TRUE  );
  glPushMatrix();
  glRotatef( -90, 1.0f, 0.0f, 0.0f );
  glTranslatef( 0.0f, 0.0f, -altura/2.0f );
  gluCylinder( qobj, r_sup, r_inf, altura, segmentos, 1 );
  glPushMatrix();
  glRotatef( 180, 1.0f, 0.0f, 0.0f );
  gluDisk( qobj, 0.0f, r_sup, segmentos, 1 );
  glPopMatrix();
  glTranslatef( 0.0f, 0.0f, altura );
  gluDisk( qobj, 0.0f, r_inf, segmentos, 1 );
  glPopMatrix();
  gluDeleteQuadric( qobj );
  glShadeModel( GL_SMOOTH );
}

