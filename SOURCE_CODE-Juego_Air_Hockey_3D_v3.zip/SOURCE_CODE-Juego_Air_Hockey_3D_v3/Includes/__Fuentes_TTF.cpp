//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 31/03/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

#include "Fuentes_TTF.h"

c_fuente_TTF::c_fuente_TTF( const char *fuente_nombre, GLint tipo, GLint fuente_size, bool text_compresion   ) {
  atexit( SDL_Quit ); 
  if ( TTF_Init() < 0 ) {
    // std::cerr << "No se pudo iniciar SDL_ttf: " << SDL_GetError() << std::endl;
    TTF_Quit(); exit(1);
  }   
  fuente_TTF = TTF_OpenFont( fuente_nombre, fuente_size ); 
  if ( !fuente_TTF ) {
    // std::cerr << "No se pudo cargar fuente TTF: " << SDL_GetError() << std::endl;
    TTF_Quit(); exit(1);
  }
  estilo = tipo;
  TTF_SetFontStyle( fuente_TTF, estilo );
  SDL_EnableUNICODE(1); TTF_ByteSwappedUNICODE(1);
  alto =  TTF_FontHeight( fuente_TTF );
  maxh = alto * 16;
  if      ( maxh < 65   ) wh = 64;
  else if ( maxh < 129  ) wh = 128;
  else if ( maxh < 257  ) wh = 256; 
  else if ( maxh < 513  ) wh = 512;
  else if ( maxh < 1025 ) wh = 1024;
  else if ( maxh < 2049 ) wh = 2048;
  else { 
    // std::cerr << "Tama�o de Fuente demasiado grande: " << fuente_size << std::endl;
    exit(1);
  };
  #if SDL_BYTEORDER == SDL_BIG_ENDIAN
    tmp = SDL_CreateRGBSurface( SDL_SWSURFACE, wh, wh, 24, 0xff0000, 0x00ff00, 0x0000ff, 0x000000 );
  #else
    tmp = SDL_CreateRGBSurface( SDL_SWSURFACE, wh, wh, 24, 0x0000ff, 0x00ff00, 0xff0000, 0x000000 );
  #endif
  if( tmp == NULL) {
    // std::cerr << "CreateRGBSurface ha fallado: " << SDL_GetError() << std::endl;
    exit(1);
  }
  SDL_FillRect( tmp, NULL, SDL_MapRGB( tmp->format, 0, 0, 0 ) );        
  caracter = new s_caracter[256];
  letra = 0;
  tmp_rect.x = 0;  tmp_rect.y = 0;
  tmp_rect.w = 0;  tmp_rect.h = alto;
  for ( GLint iy = 0; iy <16; iy++ ) {
    tmp_rect.x = 0; 
    for ( GLint ix = 0; ix < 16; ix++ ) {
      sprintf( texto, "%c", letra );
      tmp_texto[letra] = TTF_RenderText_Shaded( fuente_TTF, texto, (SDL_Color){ 255, 255, 255 }, (SDL_Color){ 0, 0, 0 } ); 
      TTF_GlyphMetrics( fuente_TTF, letra, &minx, &maxx, NULL, NULL, &avance );
      if( estilo & 0x02 ) caracter[letra].ancho = ( avance + maxx  ) >> 1;
      else caracter[letra].ancho = avance;
      tmp_rect.w = caracter[letra].ancho;
      tmp_rect.h = alto;
	  SDL_BlitSurface( tmp_texto[letra], NULL, tmp, &tmp_rect);
      tmp_rect.x += alto;
      letra++ ;
    }
    tmp_rect.y += alto; 
  }     
  for ( GLint i = 0; i < 256; i++ ) {
    SDL_FreeSurface( tmp_texto[i] ); 
    tmp_texto[i] = NULL;
  }
  TTF_CloseFont( fuente_TTF );  fuente_TTF = NULL;
  TTF_Quit();                           
  glGenTextures( 1, &text_ttf );
  glBindTexture( GL_TEXTURE_2D, text_ttf );
  glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
  glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
  if ( text_compresion )
    glTexImage2D( GL_TEXTURE_2D, 0, GL_COMPRESSED_RGB, tmp->w, tmp->h, 0, GL_RGB, GL_UNSIGNED_BYTE, tmp->pixels );
  else
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, tmp->w, tmp->h, 0, GL_RGB, GL_UNSIGNED_BYTE, tmp->pixels );
  SDL_FreeSurface( tmp ); tmp = NULL;
  base  = glGenLists( 256 );
  glBindTexture( GL_TEXTURE_2D, text_ttf );
  c_alto  = GLfloat(alto)/wh;
  for ( GLint loop = 0; loop < 256; loop++ ) {
    cx = alto * ( GLfloat )( loop % 16 ) ; 
    cy = alto * ( GLfloat )( loop / 16 ) ;
    cx =  cx / wh;  
    cy =  cy / wh;
    c_ancho = GLfloat(caracter[loop].ancho)/wh;
    glNewList(( base + loop ), GL_COMPILE );
      glBegin( GL_QUADS );
		glTexCoord2f( cx, cy + c_alto ); glVertex2i( 0, 0 );
		glTexCoord2f( cx + c_ancho, cy + c_alto ); glVertex2i( caracter[loop].ancho, 0 );
		glTexCoord2f( cx + c_ancho, cy ); glVertex2i( caracter[loop].ancho, alto );
        glTexCoord2f( cx, cy ); glVertex2i( 0, alto );
      glEnd( );
      glTranslated( caracter[loop].ancho, 0, 0 );
    glEndList( );
  }
  rojo = 255; verde = 255; azul = 255;              
}

c_fuente_TTF::~c_fuente_TTF( void ) {                         
  delete[] caracter;
  glDeleteTextures( 1, &text_ttf ); 
  glDeleteLists( base, 256 );  
}

void c_fuente_TTF::escribe( GLint x, GLint y, const char *texto  ) {
    glListBase( base );
    glColor3ub( rojo, verde, azul );
    glBindTexture( GL_TEXTURE_2D, text_ttf );
    glEnable( GL_BLEND );
    glLoadIdentity();
    if ( !( rojo | verde | azul ) ) {
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
      glBlendFunc( GL_ZERO, GL_ONE_MINUS_SRC_COLOR );
      glTranslated( x, V_Alto - alto - y, 0 );
      glCallLists( strlen( texto ), GL_UNSIGNED_BYTE, texto );
    } else if ( ( rojo & verde & azul ) ) {
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
      glBlendFunc( GL_ONE, GL_ONE );
      glTranslated( x, V_Alto - alto - y, 0 );
      glCallLists( strlen( texto ), GL_UNSIGNED_BYTE, texto ); 
    } else {
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
      glBlendFunc( GL_ZERO, GL_ONE_MINUS_SRC_COLOR );
      glTranslated( x, V_Alto - alto - y, 0 );
      glCallLists( strlen( texto ), GL_UNSIGNED_BYTE, texto );
      glLoadIdentity();
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
      glBlendFunc( GL_ONE, GL_ONE );
      glTranslated( x, V_Alto - alto - y, 0 );
      glCallLists( strlen( texto ), GL_UNSIGNED_BYTE, texto );    
    }
    glDisable( GL_BLEND );
}

void c_fuente_TTF::escribe_b_n( GLint x, GLint y, const char *texto  ) {
  glListBase( base );
  glLoadIdentity();
  glBindTexture( GL_TEXTURE_2D, text_ttf );
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
  glTranslated( x, V_Alto - alto - y, 0 );
  glCallLists( strlen( texto ), GL_UNSIGNED_BYTE, texto );
}

int c_fuente_TTF::ancho_de( const char *texto ) { 
  ancho_texto = 0;
  for ( GLint i = 0; i < strlen( texto ); i++ ) {
     ancho_texto += caracter[i].ancho;
  }
  return  ancho_texto;
}

void c_fuente_TTF::ver( void ) {
  glDisable( GL_CULL_FACE );
  glEnable( GL_TEXTURE_2D );
  glBindTexture( GL_TEXTURE_2D, text_ttf );
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
  glBegin( GL_QUADS );
    glTexCoord2f( 0.0f, 0.0f ); glVertex2i( -1,  1 );
    glTexCoord2f( 0.0f, 1.0f ); glVertex2i( -1, -1 ); 
    glTexCoord2f( 1.0f, 1.0f ); glVertex2i(  1, -1 ); 
    glTexCoord2f( 1.0f, 0.0f ); glVertex2i(  1,  1 ); 
  glEnd( );
  glDisable( GL_TEXTURE_2D );
  glEnable( GL_CULL_FACE );
}

