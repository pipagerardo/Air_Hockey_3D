//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 31/03/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

#include "Aleatorio.h"

// -------------------------------------------------------------------------
// Numero Aleatorio Int
// -------------------------------------------------------------------------
const int rnd_int( int min, int max ) {
  if ( ( max - min ) > RAND_MAX ) { 
    // std::cerr <<"Error Aleatorio_int() Rango maximo "<< RAND_MAX << std::endl;
    return RAND_MAX;
  }
  return min + ( rand() % ( max - min + 1 ) ) ;
};

// -------------------------------------------------------------------------
// Numero Aleatorio Float
// -------------------------------------------------------------------------
const float rnd_float( float min, float max ) {
  static float limite = pow( 2, sizeof(float) * 8);
  if ( ( max - min ) > limite ) { 
    // std::cerr <<"Error Aleatorio_float() Rango maximo "<< limite << std::endl;
    return limite;
  } 
  float maximo =  (float)RAND_MAX;
  float aleatorio = (float)rand();
  aleatorio /= maximo;
  if      ( aleatorio < 0.0009f ) return min;
  else if ( aleatorio > 0.9990f ) return max;
  aleatorio =  min + ( aleatorio * ( max - min ) ) ;
  if (( aleatorio <  0.0009f ) && ( aleatorio > -0.0009f ) ) return 0.0f;
  return aleatorio;
};
