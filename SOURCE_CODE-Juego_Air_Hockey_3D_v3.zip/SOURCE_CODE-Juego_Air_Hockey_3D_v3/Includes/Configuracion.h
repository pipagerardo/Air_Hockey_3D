//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 28/08/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

#ifndef _Configuracion_
#define _Configuracion_

extern int V_Ancho, V_Alto, VENTANA;
extern int MUSICA, SONIDO, CREDITOS;
extern int NIVEL;
extern int GANAR, TANTOS_1, TANTOS_2, TANTOS_3;
extern int COLOR_J1[6];
extern int COLOR_J2[6];
extern int COLOR_FICHA[6];
extern float POSICION_LUZ[3];
extern int SOMBRAS, REFLEJOS, CALIDAD_TEXT;
extern int FOTOGRAMAS, MOTOR_FISICO, VER_FOTOGRAMAS;
extern int IMAGEN, EXTENSIONES;
extern int DIRECCION_ASISTIDA;

#define N_Ventana    "Air Hockey 3D, Curso SDL con OpenGL y Bullet."
#define Nombre_Icono "Imagen/Icono/Icono.png"

// * * * CONFIGURACION DEL TECLADO * * *
#define T_P          SDLK_p  // Activa o desactiva la Pausa.
#define T_M          SDLK_m  // Activa o desactiva la m�sica.
#define T_Cursor     SDLK_c  // Activa o desactiva el cursor del rat�n.
#define T_MC         SDLK_r  // Activa o desactiva mover la c�mara.


// * * * CONFIGURACI�N SDL + OPENGL * * *
#define RF         0.0f    // Componente RED   del Fondo
#define GF         0.0f    // Componente GREEN del Fondo
#define BF         0.0f    // Componente BLUE  del Fondo
#define AF         0.0f    // Componente ALPHA del Fondo

// * * * CONFIGURACI�N MATEM�TICA * * *
#ifndef M_PI
  #define M_PI 3.14159265358979323846
#endif
#ifndef M_PI_2
  #define M_PI_2 1.57079632679489661923
#endif
#define PI2 6.28318530717958647692
#ifndef FALSE
  #define FALSE 0
  #define TRUE  1
#endif
     
#endif
