//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 28/08/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------
//-- Incluir la librer�a est�tica "libbullet.a" y su archivo de cabecera      --
//--       LINKER -lbullet         #include <btBulletDynamicsCommon.h>        --
//------------------------------------------------------------------------------
// LINKER:
// -lmingw32 -lSDLmain -lSDL -lSDL_image -lSDL_mixer -lopengl32 -lglu32 -lbullet -mwindows
// -----------------------------------------------------------------------------
// INCLUDES:
// -SDL_con_OpenGL.h   -Configuracion.h   -Entorno.h 
// -Fuentes_TTF.h      -Mirror.h          -Luces.h 
// -Materiales.h       -Texturas_2D.h     -Aleatorio.h 
// -Multitextura.h     -Sonido.h          -Figuras.h
// -Calculo_Normales.h -Cargador_Obj.h    -Sombras.h
// -Bullet.h
// -----------------------------------------------------------------------------

#include "../Includes/SDL_con_OpenGL.h"
#include "../Includes/Fuentes_Bitmap.h"
#include "../Includes/Luces.h"
#include "../Includes/Materiales.h"
#include "../Includes/Texturas_2D.h"
#include "../Includes/Figuras.h"
#include "../Includes/Multitextura.h"
#include "../Includes/Sonido.h"
#include "../Includes/Cargador_Obj.h"
#include "Bullet.h"

//-- VARIABLES GLOBALES DE CONFIGURACI�N ---------------------------------------
int V_Ancho = 800, V_Alto = 600, VENTANA = 0;
int MUSICA = 1, SONIDO = 1, CREDITOS = 1;
int NIVEL = 1;
int GANAR = 5, TANTOS_1 = 2, TANTOS_2 = 3, TANTOS_3 = 4;
int COLOR_J1[6] = {   0,   0, 255,    0,   0, 127 };
int COLOR_J2[6] = { 255,   0,   0,  127,   0,   0 };
int COLOR_FICHA[6] = { 255, 255,   0,  127, 127,   0 };
float POSICION_LUZ[3] = { 4.0f, 4.0f, 4.0f };
int SOMBRAS = 1, REFLEJOS = 1, CALIDAD_TEXT = 3;
int FOTOGRAMAS = 40, MOTOR_FISICO = 20, VER_FOTOGRAMAS = 0;
int DIRECCION_ASISTIDA = 0;
int IMAGEN = 0, EXTENSIONES = 0;

int main(int argc, char *argv[]) {
//-- INICIO DE MAIN ------------------------------------------------------------

  //----------------------------------------------------------------------------
  //-- CARGAR LA CONFIGURACI�N -------------------------------------------------
  //----------------------------------------------------------------------------
  std::string T_Cargando( "CARGANDO..." );
  std::string T_Nivel( "Nivel:" );
  std::string T_Ganador1( "GANASTE." );
  std::string T_Ganador2( "PERDISTE." );
  std::string T_Salir( "Pulsa Escape para salir," );
  std::string T_Repetir( "Espacio u Intro repetir." );
  std::string T_Fin( "Gracias y adi�s." );
  std::string T_Musica[4];
  T_Musica[0] = "Musicas/Musica_1.xm";  
  T_Musica[1] = "Musicas/Musica_2.xm"; 
  T_Musica[2] = "Musicas/Musica_3.xm"; 
  T_Musica[3] = "Musicas/Musica_4.xm";
  std::ifstream Archivo;
  Archivo.open("Configuracion.txt", std::ios::in );
  if ( Archivo.is_open() ) {   
    std::string linea;
    while ( !Archivo.eof() ) {
      getline( Archivo, linea );   
      if ( linea[0] == '#' ) {
        switch( linea[1] ) {
          case 'w': sscanf( linea.c_str(), "#w %d %d %d", &V_Ancho, &V_Alto, &VENTANA ); break;
          case 'm': sscanf( linea.c_str(), "#m %d %d %d", &MUSICA, &SONIDO, &CREDITOS ); break;
          case 'n': sscanf( linea.c_str(), "#n %d", &NIVEL ); break;
          case 'g': sscanf( linea.c_str(), "#g %d %d %d %d", &GANAR, &TANTOS_1, &TANTOS_2, &TANTOS_3 ); break;
          case '1': sscanf( linea.c_str(), "#1 Dif %d %d %d Amb %d %d %d", &COLOR_J1[0], &COLOR_J1[1], &COLOR_J1[2], &COLOR_J1[3], &COLOR_J1[4], &COLOR_J1[5] ); break;
          case '2': sscanf( linea.c_str(), "#2 Dif %d %d %d Amb %d %d %d", &COLOR_J2[0], &COLOR_J2[1], &COLOR_J2[2], &COLOR_J2[3], &COLOR_J2[4], &COLOR_J2[5] ); break;
          case 'f': sscanf( linea.c_str(), "#f Dif %d %d %d Amb %d %d %d", &COLOR_FICHA[0], &COLOR_FICHA[1], &COLOR_FICHA[2], &COLOR_FICHA[3], &COLOR_FICHA[4], &COLOR_FICHA[5] ); break;
          case 'l': sscanf( linea.c_str(), "#l %f %f %f", &POSICION_LUZ[0], &POSICION_LUZ[1], &POSICION_LUZ[2] ); break;
          case 's': sscanf( linea.c_str(), "#s %d %d %d", &SOMBRAS, &REFLEJOS, &CALIDAD_TEXT ); break;
          case 'r': sscanf( linea.c_str(), "#r %d %d %d", &FOTOGRAMAS, &MOTOR_FISICO, &VER_FOTOGRAMAS ); break;
          case 'd': sscanf( linea.c_str(), "#d %d", &DIRECCION_ASISTIDA ); break;
          case 'i': sscanf( linea.c_str(), "#i %d %d", &IMAGEN, &EXTENSIONES );  break;
          case 't':
            getline( Archivo, T_Cargando ); 
            getline( Archivo, T_Nivel ); 
            getline( Archivo, T_Ganador1 ); 
            getline( Archivo, T_Ganador2 );
            getline( Archivo, T_Salir ); 
            getline( Archivo, T_Repetir ); 
            getline( Archivo, T_Fin ); 
          break;
        }
      }
    }
    Archivo.clear();
    Archivo.close();
    if      ( V_Ancho < 320  ) V_Ancho = 320;
    else if ( V_Ancho > 1440 ) V_Ancho = 1440;
    if      ( V_Alto  < 200  ) V_Alto  = 200;
    else if ( V_Alto  > 900  ) V_Alto  = 900;
    if      ( NIVEL   < 1    ) NIVEL = 1;
    else if ( NIVEL   > 5    ) NIVEL = 5;
    if      ( GANAR   < 5    ) GANAR = 5;
    else if ( GANAR   > 20   ) GANAR = 20;
    for ( int i = 0; i < 6; i++ ) {
      if      ( COLOR_J1[i] > 255 ) COLOR_J1[i] = 255;
      else if ( COLOR_J1[i] < 0   ) COLOR_J1[i] = 0;
      if      ( COLOR_J2[i] > 255 ) COLOR_J2[i] = 255;
      else if ( COLOR_J2[i] < 0   ) COLOR_J2[i] = 0;
      if      ( COLOR_FICHA[i] > 255 ) COLOR_FICHA[i] = 255;
      else if ( COLOR_FICHA[i] < 0   ) COLOR_FICHA[i] = 0;
    }
    if      ( CALIDAD_TEXT < 0 ) CALIDAD_TEXT = 0;
    else if ( CALIDAD_TEXT > 3 ) CALIDAD_TEXT = 3;
    if      ( FOTOGRAMAS < 20 ) FOTOGRAMAS = 20;
    else if ( FOTOGRAMAS > 60 ) FOTOGRAMAS = 60;
    if      ( MOTOR_FISICO < 4 ) MOTOR_FISICO = 4;
    else if ( MOTOR_FISICO > 60 ) MOTOR_FISICO = 60;
  } else {
    std::ofstream Salida("Configuracion.txt");
    Salida << "//---------------------------------------------------" << std::endl;
    Salida << "// * * * CONFIGURACI�N DEL JUEGO AIR HOCKEY 3D * * *" << std::endl;
    Salida << "//---------------------------------------------------" << std::endl;
    Salida << "// Autor: Pipagerardo  E-Mail: pipagerardo@hotmail.es" << std::endl;
    Salida << "//---------------------------------------------------" << std::endl;
    Salida << "// #w Ancho_Ventana[320-1440] Alto_Ventana[200-900] Ventana[0-1]" << std::endl;
    Salida << "// #m Musica[0-1] Sonido[0-1] Creditos[0-1]" << std::endl;
    Salida << "// #n Nivel_del_Juego[1-5]" << std::endl;
    Salida << "// #g Tantos_para_Ganar[5-20] Objeto_1[0-1000] Objeto_2[0-1000] Objeto_3[0-1000]" << std::endl;
    Salida << "// #1 Jugador_1_Rojo[0-255] Jugador_1_Verde[0-255] Jugador_1_Azul[0-255]" << std::endl;
    Salida << "// #2 Jugador_2_Rojo[0-255] Jugador_2_Verde[0-255] Jugador_2_Azul[0-255]" << std::endl;
    Salida << "// #f Ficha_Rojo[0-255] Ficha_Verde[0-255] Ficha_Azul[0-255]" << std::endl;
    Salida << "// #l Posicion_Luz_X[+-10.0f] Posicion_Luz_Y[+-10.0f] Posicion_Luz_Z[+-10.0f]" << std::endl;
    Salida << "// #s Sombras[0-1] Reflejos[0-1] Calidad_Texturas[0-3]" << std::endl;
    Salida << "// #r Fotogramas[20-60] Calidad_Motor_Fisico[4-60] Ver_Retardo[0-1]" << std::endl;
    Salida << "// #d Direccion_Asistida_del_Mando[0-1]" << std::endl;
    Salida << "// #i Guarda_Pantalla_en_BMP_al_salir[0-1] Guarda_Extensiones_Tarjeta[0-1]" << std::endl;
    Salida << "// #t Los_Textos_para_traducir_si_se_desea" << std::endl;
    Salida << "//---------------------------------------------------" << std::endl;
    Salida << "#w 800 600 0" << std::endl;
    Salida << "#m 1 1 1" << std::endl;
    Salida << "#n 1" << std::endl;
    Salida << "#g 5 2 3 4" << std::endl;
    Salida << "#1 Dif 0 0 255 Amb 0 0 127" << std::endl;
    Salida << "#2 Dif 255 0 0 Amb 127 0 0" << std::endl;
    Salida << "#f Dif 255 255 0 Amb 127 127 0" << std::endl;
    Salida << "#l 4.0 4.0 4.0" << std::endl;
    Salida << "#s 1 1 3" << std::endl;
    Salida << "#r 60 20 0" << std::endl;
    Salida << "#d 0" << std::endl;
    Salida << "#i 0 0" << std::endl;
    Salida << "#t" << std::endl;
    Salida << "CARGANDO..." << std::endl;
    Salida << "Nivel:" << std::endl;
    Salida << "GANASTE." << std::endl;
    Salida << "PERDISTE." << std::endl;
    Salida << "Pulsa Escape para salir," << std::endl;
    Salida << "Espacio u Intro repetir." << std::endl;
    Salida << "Gracias y adi�s." << std::endl;
    Salida.close();  
  }
  //----------------------------------------------------------------------------
  //-- FIN DE CARGAR LA CONFIGURACI�N ------------------------------------------
  //----------------------------------------------------------------------------
  
  //-- CREACION DEL ENTORNO 3D -------------------------------------------------
  c_sdl_con_opengl *sdl_con_opengl = new c_sdl_con_opengl;
  c_entorno *entorno = new c_entorno( "Imagen/Cube_Maps/Cielo_Cielo/", sdl_con_opengl->Texture_Compression );

  //-- CREACION DE UNA FUENTE DE TEXTO -----------------------------------------
  c_fuente_bitmap *fuente = new c_fuente_bitmap( "Fuentes/Fuente.png", sdl_con_opengl->Texture_Compression );
  char texto[256];  // -- PARA ALMACENAR CADENAS DE TEXTO       -- //
  SDL_WarpMouse( V_Ancho >> 1, V_Alto >> 1 );
  SDL_ShowCursor( SDL_DISABLE );
  SDL_WM_GrabInput( SDL_GRAB_ON );
  sdl_con_opengl->empieza();
    sdl_con_opengl->empieza_ortho_2D(); 
    fuente->escribe( 
      ( V_Ancho - fuente->ancho_de( T_Cargando.c_str() ) ) >> 1, 
      ( V_Alto >> 1 ) - fuente->altura(), 
      T_Cargando.c_str()
    );
    sdl_con_opengl->termina_ortho_2D();
  sdl_con_opengl->termina(); 
  sdl_con_opengl->terminar = false;

  //-- MUSICA Y SONIDO ---------------------------------------------------------
  c_sonido *choque;
  c_sonido *tanto;
  c_musica *musica;
  int N_Musica = rnd_int( 0, 3 );
  if ( SONIDO || MUSICA || CREDITOS ) Inicia_SDL_mixer();
  if ( SONIDO ) {
    Mix_AllocateChannels(2);
    choque = new c_sonido( "Sonidos/Choque.wav", 0, 64 );
    tanto  = new c_sonido( "Sonidos/Tanto.wav",  1, 64 );
  }
  if ( MUSICA || CREDITOS ) musica = new c_musica();
  
  //-- CREACION DEL ENTORNO 3D -------------------------------------------------
  if ( sdl_con_opengl->Texture_Cube_Map ) entorno->crea_cube_map();
 
  //-- CREACION DEL MULTITEXTURA -----------------------------------------------
  if ( sdl_con_opengl->Multitexture ) Inicia_Multitextura();

  //-- CREAMOS LAS LUCES -------------------------------------------------------
  c_luz *luz = new c_luz[1];
  luz[0].position( POSICION_LUZ[0], POSICION_LUZ[1], POSICION_LUZ[2] );
  luz[0].diffuse( 1.0f, 1.0f, 1.0f );
  luz[0].ambient( 0.3f, 0.3f, 0.3f );
  // luz[0].direccional( GL_LIGHT0 );
  luz[0].puntual( GL_LIGHT0 );
  luz[0].posiciona();
  
  //-- CREAMOS LOS MATERIALES --------------------------------------------------
  c_material *material = new c_material[5];
  //-- BLANCO -----------------------------
  material[0].diffuse(  0.9f, 0.9f, 0.9f );
  material[0].ambient(  0.6f, 0.6f, 0.6f );
  material[0].specular( 1.0f, 1.0f, 1.0f );
  material[0].phongsize( 32.0f );  
  //-- JUGADOR 1 ------------------------------
  material[1].diffuse(  COLOR_J1[0]/255.0f, COLOR_J1[1]/255.0f, COLOR_J1[2]/255.0f );
  material[1].ambient(  COLOR_J1[3]/255.0f, COLOR_J1[4]/255.0f, COLOR_J1[5]/255.0f );
  material[1].specular( 1.0f, 1.0f, 1.0f );
  material[1].phongsize( 16.0f );
  //-- JUGADOR 2 -------------------------------
  material[2].diffuse(  COLOR_J2[0]/255.0f, COLOR_J2[1]/255.0f, COLOR_J2[2]/255.0f );
  material[2].ambient(  COLOR_J2[3]/255.0f, COLOR_J2[4]/255.0f, COLOR_J2[5]/255.0f );
  material[2].specular( 1.0f, 1.0f, 1.0f );
  material[2].phongsize( 16.0f );
  //-- FICHA -------------------------------
  material[3].diffuse(  COLOR_FICHA[0]/255.0f, COLOR_FICHA[1]/255.0f, COLOR_FICHA[2]/255.0f );
  material[3].ambient(  COLOR_FICHA[3]/255.0f, COLOR_FICHA[4]/255.0f, COLOR_FICHA[5]/255.0f );
  material[3].specular( 1.0f, 1.0f, 1.0f );
  material[3].phongsize( 16.0f );
  //-- SOMBRA -------------------------------
  material[4].diffuse(  0.0f, 0.0f, 0.0f );
  material[4].ambient(  0.0f, 0.0f, 0.0f );
  material[4].specular( 0.0f, 0.0f, 0.0f );
  material[4].phongsize( 1.0f );
  material[4].alpha( 0.2f );
    
  //-- CREAMOS LAS TEXTURAS ----------------------------------------------------
  c_textura_2D *textura_2D = new c_textura_2D[4];
  textura_2D[0].carga_2DMipmaps( "Imagen/Tabla.jpg", CALIDAD_TEXT, sdl_con_opengl->Texture_Compression );
  textura_2D[1].carga_2DMipmaps( "Imagen/Balon.jpg", 0, sdl_con_opengl->Texture_Compression );
  textura_2D[2].carga_2DMipmaps( "Imagen/Caja.jpg", CALIDAD_TEXT, sdl_con_opengl->Texture_Compression );
  textura_2D[3].carga_2DMipmaps( "Imagen/Lata_Arriba.jpg", CALIDAD_TEXT, sdl_con_opengl->Texture_Compression );

  // -- CARGAMOS LOS MODELOS OBJ -----------------------------------------------
  C_Obj *Modelo_OBJ = new C_Obj[3];
  Modelo_OBJ[0].Carga( "Objetos_3D/Mesa.obj" );
  Modelo_OBJ[1].Carga( "Objetos_3D/Mando.obj" );
  Modelo_OBJ[2].Carga( "Objetos_3D/Ficha.obj" );
  c_textura_2D *text_2D_obj = new c_textura_2D[ Modelo_OBJ[0].N_Texturas() ];
  Modelo_OBJ[0].Carga_Texturas( text_2D_obj, CALIDAD_TEXT, sdl_con_opengl->Texture_Compression );
  
  //-- CREAMOS LAS LISTAS COMPILADAS -------------------------------------------
  glListBase( 0 );
  GLuint lista = glGenLists(9);

  // -- DIBUJAMOS LA MESA ------------------------------------------------------
  glNewList( lista + 0, GL_COMPILE );
    material[0].activa();
    if ( sdl_con_opengl->Texture_Cube_Map && sdl_con_opengl->Multitexture && REFLEJOS ) {
      glActiveTextureARB( GL_TEXTURE1_ARB );
      entorno->activa_cube_map();
      glActiveTextureARB( GL_TEXTURE0_ARB ); 
    }
    textura_2D[0].activa();
    glBegin( GL_QUADS );
      glNormal3f( 0.0f, 1.0f, 0.0f ); 
      glTexCoord2f( 0.0f, 0.0f );    glVertex3f( -1.51f, 0.1f,  3.0f );
      glTexCoord2f( 0.5f, 0.0f );    glVertex3f(  0.0f,  0.1f,  3.0f );
      glTexCoord2f( 0.5f, 0.1666f ); glVertex3f(  0.0f,  0.1f,  2.0f );
      glTexCoord2f( 0.0f, 0.1666f ); glVertex3f( -1.51f, 0.1f,  2.0f );
      glTexCoord2f( 0.5f, 0.0f );    glVertex3f(  0.0f,  0.1f,  3.0f );
      glTexCoord2f( 1.0f, 0.0f );    glVertex3f(  1.51f, 0.1f,  3.0f );
      glTexCoord2f( 1.0f, 0.1666f ); glVertex3f(  1.51f, 0.1f,  2.0f );
      glTexCoord2f( 0.5f, 0.1666f);  glVertex3f(  0.0f,  0.1f,  2.0f );
      glTexCoord2f( 0.0f, 0.1666f ); glVertex3f( -1.51f, 0.1f,  2.0f );
      glTexCoord2f( 0.5f, 0.1666f ); glVertex3f(  0.0f,  0.1f,  2.0f );
      glTexCoord2f( 0.5f, 0.3333f ); glVertex3f(  0.0f,  0.1f,  1.0f );
      glTexCoord2f( 0.0f, 0.3333f ); glVertex3f( -1.51f, 0.1f,  1.0f );
      glTexCoord2f( 0.5f, 0.1666f ); glVertex3f(  0.0f,  0.1f,  2.0f );
      glTexCoord2f( 1.0f, 0.1666f ); glVertex3f(  1.51f, 0.1f,  2.0f );
      glTexCoord2f( 1.0f, 0.3333f ); glVertex3f(  1.51f, 0.1f,  1.0f );
      glTexCoord2f( 0.5f, 0.3333f ); glVertex3f(  0.0f,  0.1f,  1.0f );
      glTexCoord2f( 0.0f, 0.3333f ); glVertex3f( -1.51f, 0.1f,  1.0f );
      glTexCoord2f( 0.5f, 0.3333f ); glVertex3f(  0.0f,  0.1f,  1.0f );
      glTexCoord2f( 0.5f, 0.5f );    glVertex3f(  0.0f,  0.1f,  0.0f );
      glTexCoord2f( 0.0f, 0.5f );    glVertex3f( -1.51f, 0.1f,  0.0f );
      glTexCoord2f( 0.5f, 0.3333f ); glVertex3f(  0.0f,  0.1f,  1.0f );
      glTexCoord2f( 1.0f, 0.3333f ); glVertex3f(  1.51f, 0.1f,  1.0f );
      glTexCoord2f( 1.0f, 0.5f );    glVertex3f(  1.51f, 0.1f,  0.0f );
      glTexCoord2f( 0.5f, 0.5f );    glVertex3f(  0.0f,  0.1f,  0.0f );
      glTexCoord2f( 0.0f, 0.5f );    glVertex3f( -1.51f, 0.1f,  0.0f );
      glTexCoord2f( 0.5f, 0.5f );    glVertex3f(  0.0f,  0.1f,  0.0f );
      glTexCoord2f( 0.5f, 0.6666f ); glVertex3f(  0.0f,  0.1f, -1.0f );
      glTexCoord2f( 0.0f, 0.6666f ); glVertex3f( -1.51f, 0.1f, -1.0f );
      glTexCoord2f( 0.5f, 0.5f );    glVertex3f(  0.0f,  0.1f,  0.0f );
      glTexCoord2f( 1.0f, 0.5f );    glVertex3f(  1.51f, 0.1f,  0.0f );
      glTexCoord2f( 1.0f, 0.6666f ); glVertex3f(  1.51f, 0.1f, -1.0f );
      glTexCoord2f( 0.5f, 0.6666f ); glVertex3f(  0.0f,  0.1f, -1.0f );
      glTexCoord2f( 0.0f, 0.6666f ); glVertex3f( -1.51f, 0.1f, -1.0f );
      glTexCoord2f( 0.5f, 0.6666f ); glVertex3f(  0.0f,  0.1f, -1.0f );
      glTexCoord2f( 0.5f, 0.8333f ); glVertex3f(  0.0f,  0.1f, -2.0f );
      glTexCoord2f( 0.0f, 0.8333f ); glVertex3f( -1.51f, 0.1f, -2.0f );
      glTexCoord2f( 0.5f, 0.6666f ); glVertex3f(  0.0f,  0.1f, -1.0f );
      glTexCoord2f( 1.0f, 0.6666f ); glVertex3f(  1.51f, 0.1f, -1.0f );
      glTexCoord2f( 1.0f, 0.8333f ); glVertex3f(  1.51f, 0.1f, -2.0f );
      glTexCoord2f( 0.5f, 0.8333f ); glVertex3f(  0.0f,  0.1f, -2.0f );
      glTexCoord2f( 0.0f, 0.8333f ); glVertex3f( -1.51f, 0.1f, -2.0f );
      glTexCoord2f( 0.5f, 0.8333f ); glVertex3f(  0.0f,  0.1f, -2.0f );
      glTexCoord2f( 0.5f, 1.0f );    glVertex3f(  0.0f,  0.1f, -3.0f );
      glTexCoord2f( 0.0f, 1.0f );    glVertex3f( -1.51f, 0.1f, -3.0f );
      glTexCoord2f( 0.5f, 0.8333f ); glVertex3f(  0.0f,  0.1f, -2.0f );
      glTexCoord2f( 1.0f, 0.8333f ); glVertex3f(  1.51f, 0.1f, -2.0f );
      glTexCoord2f( 1.0f, 1.0f );    glVertex3f(  1.51f, 0.1f, -3.0f );
      glTexCoord2f( 0.5f, 1.0f );    glVertex3f(  0.0f,  0.1f, -3.0f );
    glEnd();
    if ( sdl_con_opengl->Texture_Cube_Map && sdl_con_opengl->Multitexture && REFLEJOS ) {
      glActiveTextureARB( GL_TEXTURE1_ARB ); 
      entorno->desactiva_cube_map();
      glActiveTextureARB( GL_TEXTURE0_ARB );
    }
    textura_2D[0].desactiva();
  glEndList();

  // -- DIBUJAMOS EL BORDE -----------------------------------------------------
  glNewList( lista + 1, GL_COMPILE );
    Modelo_OBJ[0].Dibuja_Todo();
  glEndList();

  //-- DIBUJAMOS EL MANDO A BAJA RESOLUCI�N  -----------------------------------
  glNewList( lista + 2, GL_COMPILE );
    glPushMatrix(); 
    glTranslatef(  0.0f, 0.05f, 0.0f );
    Dibuja_Cilindro( 0.18f, 0.18f, 0.18f, 32, true );
    // glTranslatef(  0.0f, 0.09f, 0.0f );
    // Dibuja_Esfera( 0.12f, 16, true );
    glPopMatrix();
  glEndList();
  
  //-- DIBUJAMOS EL MANDO SIN MATERIALES A ALTA RESOLUCI�N ---------------------
  glNewList( lista + 3, GL_COMPILE );
    Modelo_OBJ[1].Dibuja_Objeto_Sin_Material( 0 ); 
  glEndList();
    
  //-- DIBUJAMOS LA FICHA A BAJA RESOLUCI�N ------------------------------------
  glNewList( lista + 4, GL_COMPILE );
    Dibuja_Cilindro( 0.12f, 0.12f, 0.04f, 32,true );
  glEndList();
    
  //-- DIBUJAMOS LA FICHA SIN MATERIALES A ALTA RESOLUCI�N ---------------------
  glNewList( lista + 5, GL_COMPILE );
    Modelo_OBJ[2].Dibuja_Objeto_Sin_Material( 0 ); 
  glEndList();
  
  //-- DIBUJAMOS UNA ESFERA ----------------------------------------------------
  glNewList( lista + 6, GL_COMPILE );
    textura_2D[1].activa();
    Dibuja_Esfera( 0.12f, 16, true );
    textura_2D[1].desactiva();
  glEndList();

  //-- DIBUJAMOS UN CUBO -------------------------------------------------------
  glNewList( lista + 7, GL_COMPILE );
    textura_2D[2].activa();
    Dibuja_Cubo_T1( 0.1f, 0.1f, 0.1f, false );
    textura_2D[2].desactiva();
  glEndList();

  //-- DIBUJAMOS UN CILINDRO ---------------------------------------------------
  glNewList( lista + 8, GL_COMPILE );
    textura_2D[3].activa();
    Dibuja_Cilindro( 0.18f, 0.18f, 0.16f, 32, true );
    textura_2D[3].desactiva();
  glEndList();

  delete[] Modelo_OBJ;         // -- BORRAMOS LOS OBJETOS     --
  
  //----------------------------------------------------------------------------
  //-- CREACION DEL MUNDO FISICO 3D                                           --
  //----------------------------------------------------------------------------  
  c_bullet *bullet = new c_bullet( sdl_con_opengl, material );

  //----------------------------------------------------------------------------
  //-- POSICI�N DE LA C�MARA                                                  --
  //----------------------------------------------------------------------------
  sdl_con_opengl->enfoque_camara(  0.0f, -0.6f, 2.75436f - 2.1f );
  sdl_con_opengl->posicion_camara( 0.0f,  2.1f, 2.75436f + 1.8f );
  
  //----------------------------------------------------------------------------
  //-- CREDITOS INICIALES                                                     --
  //----------------------------------------------------------------------------
  if ( CREDITOS ) {
    musica->carga( "Musicas/Pipagerardo.xm", 64 );
    //-- CREAMOS LOS MATERIALES --------------------------------------------------
    c_material *cartelera_material = new c_material[4];
    cartelera_material[0].diffuse(  1.0f, 1.0f, 1.0f );
    cartelera_material[0].ambient(  1.0f, 1.0f, 1.0f );
    cartelera_material[0].specular( 0.0f, 0.0f, 0.0f );
    cartelera_material[0].alpha( 1.0f );
    cartelera_material[1].diffuse(  1.0f, 1.0f, 1.0f );
    cartelera_material[1].ambient(  1.0f, 1.0f, 1.0f );
    cartelera_material[1].specular( 0.0f, 0.0f, 0.0f );
    cartelera_material[1].alpha( 1.0f );
    cartelera_material[2].diffuse(  1.0f, 1.0f, 1.0f );
    cartelera_material[2].ambient(  1.0f, 1.0f, 1.0f );
    cartelera_material[2].specular( 0.0f, 0.0f, 0.0f );
    cartelera_material[2].alpha( 1.0f );
    cartelera_material[3].diffuse(  0.0f, 0.0f, 0.0f );
    cartelera_material[3].ambient(  0.0f, 0.0f, 0.0f );
    cartelera_material[3].specular( 0.0f, 0.0f, 0.0f );
    cartelera_material[3].alpha( 1.0f );
    //-- CREAMOS LAS TEXTURAS ----------------------------------------------------
    c_textura_2D *cartelera_imagen = new c_textura_2D[3];
    cartelera_imagen[0].carga_2DMipmaps( "Imagen/SB2010pc.png", 0, sdl_con_opengl->Texture_Compression );
    cartelera_imagen[1].carga_2DMipmaps( "Imagen/Creditos.png", 0, sdl_con_opengl->Texture_Compression );
    cartelera_imagen[2].carga_2DMipmaps( "Imagen/Pipagerardo.png", 0, sdl_con_opengl->Texture_Compression );
    //-- CREAMOS LA LISTA --------------------------------------------------------
    GLuint cartelera_lista = glGenLists(1);
    glNewList( cartelera_lista, GL_COMPILE );
      glAlphaFunc( GL_ALWAYS, 1.0 );
      glBegin( GL_QUADS );
        glTexCoord2f( 0.0f, 0.0f ); glVertex2i( 0, 0 );
        glTexCoord2f( 1.0f, 0.0f ); glVertex2i( V_Ancho, 0 );
        glTexCoord2f( 1.0f, 1.0f ); glVertex2i( V_Ancho, V_Alto );
        glTexCoord2f( 0.0f, 1.0f ); glVertex2i( 0, V_Alto );
      glEnd();
    glEndList();
    //-- DIBUJAMOS LOS CREDITOS --------------------------------------------------
    musica->reproduce();
    for( int i = 0; i<(FOTOGRAMAS*17); i++ ) {
      sdl_con_opengl->empieza( entorno );
      luz[0].posiciona();
      bullet->dibuja_todo( lista, luz[0].position() );
      sdl_con_opengl->empieza_ortho_2D(); 
        cartelera_material[2].activa();
          cartelera_imagen[2].activa();
            glCallList( cartelera_lista );
          cartelera_imagen[2].desactiva();
        cartelera_material[2].desactiva();
        if ( i > (FOTOGRAMAS*12) ) cartelera_material[2].alpha( 1.0f - ( ( i - (FOTOGRAMAS*12) ) / float(FOTOGRAMAS*4) ) );
        cartelera_material[1].activa();
          cartelera_imagen[1].activa();
            glCallList( cartelera_lista );
          cartelera_imagen[1].desactiva();
        cartelera_material[1].desactiva();
        if ( ( i > (FOTOGRAMAS*8) ) && ( i < (FOTOGRAMAS*12) ) ) cartelera_material[1].alpha( 1.0f - ( ( i - (FOTOGRAMAS*8)) / float(FOTOGRAMAS*4) ) );
        cartelera_material[0].activa();
          cartelera_imagen[0].activa();
            glCallList( cartelera_lista );
          cartelera_imagen[0].desactiva();
        cartelera_material[0].desactiva();
        if ( ( i > (FOTOGRAMAS*4) ) && ( i < (FOTOGRAMAS*8) ) ) cartelera_material[0].alpha( 1.0f - ( ( i - (FOTOGRAMAS*4) ) / float(FOTOGRAMAS*4) ) );
        cartelera_material[3].activa();
          glCallList( cartelera_lista );
        cartelera_material[3].desactiva();
        if ( i < (FOTOGRAMAS*4) ) cartelera_material[3].alpha( 1.0f - ( i / float(FOTOGRAMAS*4) ) );
      sdl_con_opengl->termina_ortho_2D();
      if ( sdl_con_opengl->termina() ) break;
    }
    glDeleteLists( cartelera_lista,  1  ); // -- BORRAMOS LAS LISTAS     --
    delete[] cartelera_imagen;
    delete[] cartelera_material;
    musica->para();
    if ( !MUSICA ) delete musica;
  }
  //----------------------------------------------------------------------------
  //-- FIN DE CREDITOS INICIALES                                              --
  //----------------------------------------------------------------------------


  //----------------------------------------------------------------------------
  //-- EMPIEZA EL JUEGO.                                                      --
  //----------------------------------------------------------------------------
  do {

    //--------------------------------------------------------------------------
    //-- CARGAMOS LA MUSICA.                                                  --
    //--------------------------------------------------------------------------
    if ( MUSICA ) {
      musica->carga( T_Musica[ N_Musica ].c_str(), 32 );
      sdl_con_opengl->toma_musica( musica );
      musica->reproduce();
      ++N_Musica; if ( N_Musica > 3 ) N_Musica = 0;
    }

    //--------------------------------------------------------------------------
    //-- PEQUE�A PAUSA INICIAL.                                               --
    //--------------------------------------------------------------------------
    sdl_con_opengl->terminar = false;
    sdl_con_opengl->repetir  = false;
    bullet->Punto_en_Juego   = false;
    bullet->inicia(); 
    SDL_WarpMouse( V_Ancho >> 1, Uint16( V_Alto / 1.5f ) );
    
    for( int i = 0; i<FOTOGRAMAS*2; i++ ) {
      sdl_con_opengl->empieza( entorno );
        luz[0].posiciona();
        SDL_WarpMouse( V_Ancho >> 1, Uint16( V_Alto / 1.5f ) );
        // bullet->simulacion();
        // bullet->que_no_se_escape_nadie();
        // bullet->donde_esta_la_ficha();
        bullet->camara();
        bullet->dibuja_todo( lista, luz[0].position() ); 
        sdl_con_opengl->empieza_ortho_2D(); 
          sprintf( texto, "%s %i", T_Nivel.c_str(), NIVEL );
          fuente->color( 255, 255, 255 ); 
          fuente->escribe( 
            ( V_Ancho - fuente->ancho_de( texto ) ) >> 1, 
            ( V_Alto >> 1 ) - fuente->altura(), texto
          );  
        sdl_con_opengl->termina_ortho_2D();
      sdl_con_opengl->termina();
    } 
  
    //--------------------------------------------------------------------------
    //-- EMPIEZA UNA PARTIDA.                                                 --
    //--------------------------------------------------------------------------
    sdl_con_opengl->terminar = false;
    sdl_con_opengl->repetir  = false;
    bullet->Punto_en_Juego   = true;
  
    do { sdl_con_opengl->empieza( entorno );
      luz[0].posiciona(); 
      bullet->simulacion();
      bullet->que_no_se_escape_nadie();
      bullet->donde_esta_la_ficha();
      bullet->control_mando_2();
      if ( SONIDO ) {
        if ( bullet->sonido_choque ) { 
          choque->volumen( bullet->volumen );
          choque->reproduce(); bullet->sonido_choque = false; 
        }
        if ( bullet->sonido_tanto ) { 
          tanto->reproduce(); bullet->sonido_tanto = false; 
        }
      }
      bullet->control_mando_1();
      bullet->camara();
      bullet->dibuja_todo( lista, luz[0].position() );
      sdl_con_opengl->empieza_ortho_2D(); 
        sprintf( texto, "%i", bullet->Puntos_2 );
        fuente->color( COLOR_J2[0], COLOR_J2[1], COLOR_J2[2] ); fuente->escribe( 0, 5, texto );
        sprintf( texto, "%i", bullet->Puntos_1 );
        fuente->color( COLOR_J1[0], COLOR_J1[1], COLOR_J1[2] ); fuente->escribe( 0, 30, texto ); 
        if ( VER_FOTOGRAMAS ) {
          sprintf( texto, "%d %d", int( sdl_con_opengl->dame_retardo() * 1000 ), int( 1000.0f / FOTOGRAMAS ) );
          fuente->color( 255, 255, 255 ); fuente->escribe( 0, 65, texto ); 
        }
      sdl_con_opengl->termina_ortho_2D();
    } while ( !sdl_con_opengl->termina() );
    sdl_con_opengl->repetir = false;
    if ( MUSICA ) { musica->para(); SDL_Delay( 200 ); }

    //--------------------------------------------------------------------------
    //-- SI HAY GANADOR.                                                      --
    //--------------------------------------------------------------------------
    if ( ( bullet->Puntos_1 >= GANAR ) || ( bullet->Puntos_2 >= GANAR ) ) {
      sdl_con_opengl->terminar = false;
      sdl_con_opengl->repetir = false;
      do { sdl_con_opengl->empieza( entorno );
        luz[0].posiciona(); 
        bullet->simulacion();
        bullet->control_mando_1();
        bullet->control_mando_2();
        bullet->camara();
        bullet->dibuja_todo( lista, luz[0].position() );
        sdl_con_opengl->empieza_ortho_2D(); 
          sprintf( texto, "%i", bullet->Puntos_2 );
          fuente->color( COLOR_J2[0], COLOR_J2[1], COLOR_J2[2]  ); fuente->escribe( 0, 5, texto );
          sprintf( texto, "%i", bullet->Puntos_1 );
          fuente->color( COLOR_J1[0], COLOR_J1[1], COLOR_J1[2]  ); fuente->escribe( 0, 30, texto ); 
          sprintf( texto, "%s %i", T_Nivel.c_str(), NIVEL );
          fuente->color( 255, 255, 255 ); 
          fuente->escribe( 
            ( V_Ancho - fuente->ancho_de( texto ) ) >> 1, 
            ( V_Alto >> 1 ) - ( fuente->altura() * 3 ), texto
          );  
          if ( bullet->Puntos_1 >= GANAR ) {
            fuente->color( COLOR_J1[0], COLOR_J1[1], COLOR_J1[2] ); 
            fuente->escribe( 
              ( V_Ancho - fuente->ancho_de( T_Ganador1.c_str() ) ) >> 1, 
              ( V_Alto >> 1 ) - fuente->altura(), T_Ganador1.c_str()
            );  
          } else {
            fuente->color( COLOR_J2[0], COLOR_J2[1], COLOR_J2[2]  ); 
            fuente->escribe( 
              ( V_Ancho - fuente->ancho_de( T_Ganador2.c_str() ) ) >> 1, 
              ( V_Alto >> 1 ) - fuente->altura(), T_Ganador2.c_str()
            );
          }
          fuente->color( 255, 255, 255 ); 
          fuente->escribe( 
            ( V_Ancho - fuente->ancho_de( T_Salir.c_str() ) ) >> 1, 
            ( V_Alto >> 1 ) + fuente->altura(), T_Salir.c_str()
            );
          fuente->escribe( 
            ( V_Ancho - fuente->ancho_de( T_Repetir.c_str() ) ) >> 1, 
            ( V_Alto >> 1 ) + ( fuente->altura() * 2 ), T_Repetir.c_str()
          );
        sdl_con_opengl->termina_ortho_2D();
      } while ( !sdl_con_opengl->termina() );
      
      if ( bullet->Puntos_1 >= GANAR ) ++NIVEL;
      if ( bullet->Puntos_2 >= GANAR ) --NIVEL;
      if      ( NIVEL   < 1    ) NIVEL = 1;
      else if ( NIVEL   > 5    ) NIVEL = 5;
    }
  
  } while ( sdl_con_opengl->terminar && sdl_con_opengl->repetir );

  if ( IMAGEN ) Captura_Pantalla( "Captura_Pantalla.BMP" );
  
  //----------------------------------------------------------------------------
  //-- DESPEDIDA.                                                             --
  //----------------------------------------------------------------------------
  for( int i = 0; i<FOTOGRAMAS*2; i++ ) {
    sdl_con_opengl->empieza( entorno );
    luz[0].posiciona();
    bullet->camara();
    bullet->dibuja_todo( lista, luz[0].position() ); 
    sdl_con_opengl->empieza_ortho_2D();
    fuente->color( 255, 255, 255 ); 
    fuente->escribe( 
      ( V_Ancho - fuente->ancho_de( T_Fin.c_str() ) ) >> 1, 
      ( V_Alto >> 1 ) - fuente->altura(), T_Fin.c_str()
    );
    sdl_con_opengl->termina_ortho_2D();
    sdl_con_opengl->termina();
  } 
  
  
  //----------------------------------------------------------------------------
  //-- CIERRE.                                                                --
  //----------------------------------------------------------------------------
  if ( SONIDO || MUSICA || CREDITOS ) Cierra_SDL_mixer();

  // -- BORRANDO OBJETOS -------------------------------------------------------
  glDeleteLists( lista,  7  ); // -- BORRAMOS LAS LISTAS      --
  delete text_2D_obj;        // -- BORRAMOS LAS TEXTURAS OBJ --
  delete[] textura_2D;         // -- BORRAMOS LAS TEXTURAS    --
  delete[] material;           // -- BORRAMOS LOS MATERIALES  --
  delete[] luz;                // -- BORRAMOS LAS LUCES       --
  delete fuente;               // -- BORRAMOS LA FUENTE       --
  delete entorno;              // -- BORAMOS  EL FONDO        --
  delete sdl_con_opengl;       // -- BORRAMOS EL ENTORNO      --
  delete bullet;               // -- BORRAMOS EL MUNDO FISICO --
  if ( SONIDO ) { delete choque; delete tanto; }
  if ( MUSICA ) delete musica;

  // std::cout << "FIN." << std::endl;
  
  // -- FIN DE MAIN ------------------------------------------------------------
  return EXIT_SUCCESS;
}
