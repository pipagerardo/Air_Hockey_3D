//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 28/08/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

#include "Bullet.h"

c_bullet::c_bullet( c_sdl_con_opengl* puntero, c_material *puntero_mat ) {   
  //----------------------------------------------------------------------------
  //-- INICIAR VARIABLES.                                                     --
  //----------------------------------------------------------------------------   
  sdl_con_opengl = puntero; 
  material = puntero_mat;
  retardo   = 1.0f / FOTOGRAMAS; 
  ejecutado = 0.0f;
  x = V_Ancho >> 1; 
  y = Uint16( V_Alto / 1.5f ); 
  camara_x = 0.0f; camara_z = 2.75436;
  escala   = 10.0f;
  Mass     = 0.0f;
  Inertia.setX( 0.0f ); Inertia.setY( 0.0f ); Inertia.setZ( 0.0f );  
  // -- TRES PUNTOS DEL SUELO EN SENTIDO ANTIHORARIO ---------------------------
  Puntos[0] = -1.51f; Puntos[1] = 0.1f; Puntos[2] = 3.0f ;
  Puntos[3] = 1.51f;  Puntos[4] = 0.1f; Puntos[5] = 3.0f;   
  Puntos[6] = 1.51f;  Puntos[7] = 0.1f; Puntos[8] = -3.0f;
  Ecuacion_del_Plano( Puntos, Plano );
  
  //----------------------------------------------------------------------------
  //-- LIBRER�A DE F�SICA BULLET                                              --
  //----------------------------------------------------------------------------
  broadphase             = new btDbvtBroadphase();
  collisionConfiguration = new btDefaultCollisionConfiguration();
  dispatcher             = new btCollisionDispatcher( collisionConfiguration );
  solver                 = new btSequentialImpulseConstraintSolver;
  dynamicsWorld          = new btDiscreteDynamicsWorld( dispatcher, broadphase, solver, collisionConfiguration );
  dynamicsWorld->setGravity( btVector3( 0, -10 * escala, 0 ) );   //-- La gravedad --
  btContactSolverInfo& info = dynamicsWorld->getSolverInfo();
  info.m_numIterations = 4;

  //----------------------------------------------------------------------------
  //-- Formas de Colisi�n ( Collision Shapes )                                --
  //----------------------------------------------------------------------------
  tabla_Shape   = new btBoxShape( escala * btVector3( 1.5f, 0.1f, 3.0f ) );
  lateral_Shape = new btBoxShape( escala * btVector3( 0.1f, 0.1f, 3.2f ) );
  frontal_Shape = new btBoxShape( escala * btVector3( 0.5f, 0.1f, 0.1f ) ); // 1.5f
  tapa_Shape    = new btBoxShape( escala * btVector3( 0.5f, 0.05f, 0.1f ) ); // 1.5f
  mesa_Shape    = new btCompoundShape( false );
    trans.setIdentity();
    trans.setOrigin( escala * btVector3( 0, 0, 0 ) );
    mesa_Shape->addChildShape( trans, tabla_Shape );
    trans.setOrigin( escala * btVector3(-1.6f, 0.2f, 0 ) );
    mesa_Shape->addChildShape( trans, lateral_Shape );
    trans.setOrigin( escala * btVector3( 1.6f, 0.2f, 0 ) );
    mesa_Shape->addChildShape( trans, lateral_Shape );
    trans.setOrigin( escala * btVector3( -1.0f, 0.2f,  3.1f ) );
    mesa_Shape->addChildShape( trans, frontal_Shape );
    trans.setOrigin( escala * btVector3(  1.0f, 0.2f,  3.1f ) );
    mesa_Shape->addChildShape( trans, frontal_Shape );
    trans.setOrigin( escala * btVector3(  0.0f, 0.25f,  3.1f ) );
    mesa_Shape->addChildShape( trans, tapa_Shape );
    trans.setOrigin( escala * btVector3( -1.0f, 0.2f, -3.1f ) );
    mesa_Shape->addChildShape( trans, frontal_Shape );
    trans.setOrigin( escala * btVector3(  1.0f, 0.2f, -3.1f ) );
    mesa_Shape->addChildShape( trans, frontal_Shape );
    trans.setOrigin( escala * btVector3(  0.0f, 0.25f, -3.1f ) );
    mesa_Shape->addChildShape( trans, tapa_Shape );
    
  ficha_Shape = new btCylinderShape( escala * btVector3( 0.12f, 0.04f, 0.12f ) );

  esfera_Shape = new btSphereShape( escala *  0.12f ); 
  
  cilindro_Shape = new btCylinderShape(escala *  btVector3( 0.18f, 0.08f, 0.18f ) );

  mando_Shape    = new btCompoundShape( false ); 
    trans.setIdentity();
    trans.setOrigin( escala * btVector3( 0, 0, 0 ) );
    mando_Shape->addChildShape( trans, cilindro_Shape );
    trans.setOrigin( escala * btVector3( 0, 0.09f, 0 ) );
    mando_Shape->addChildShape( trans, esfera_Shape );
    
  cubo_Shape   = new btBoxShape( escala * btVector3( 0.1f, 0.1f, 0.1f ) ); //-- 1 Metro cada lado. --
  
  //----------------------------------------------------------------------------
  //-- Cuerpos r�gidos. ( Rigid Bodies )                                      --
  //----------------------------------------------------------------------------
  mesa_MotionState = new btDefaultMotionState( btTransform( btQuaternion(0,0,0,1), escala * btVector3(0,0,0) ) );
  mesa_RigidBody = new btRigidBody( 0, mesa_MotionState, mesa_Shape, btVector3(0,0,0) );
  dynamicsWorld->addRigidBody( mesa_RigidBody );
  mesa_RigidBody->setCollisionFlags( mesa_RigidBody->getCollisionFlags() | btCollisionObject::CF_STATIC_OBJECT );
    mesa_RigidBody->setDamping( btScalar( 0.0f ) , btScalar( 0.0f ) );
    mesa_RigidBody->setFriction(    btScalar( 0.1f ) );
    mesa_RigidBody->setRestitution( btScalar( 0.9f ) );
    
  //----------------------------------------------------------------------------
  Mass = 0.1f;
  ficha_MotionState = new btDefaultMotionState( btTransform( btQuaternion(0,0,0,1), escala * btVector3( 0.0f, 0.19f, 0.0f ) ) );
  ficha_Shape->calculateLocalInertia( Mass, Inertia );
  ficha_RigidBody = new btRigidBody( Mass, ficha_MotionState, ficha_Shape, Inertia );
  dynamicsWorld->addRigidBody( ficha_RigidBody );
    ficha_RigidBody->setDamping( btScalar( 0.0f ) , btScalar( 0.2f ) );
    ficha_RigidBody->setFriction(    btScalar( 0.1f ) );
    ficha_RigidBody->setRestitution( btScalar( 0.8f ) );
    ficha_RigidBody->setLinearFactor(  btVector3( 1.0f, 0.1f, 1.0f ) );
    ficha_RigidBody->setAngularFactor( btVector3( 0.0f, 1.0f, 0.0f ) );
    ficha_RigidBody->setActivationState( DISABLE_DEACTIVATION );

  //----------------------------------------------------------------------------
  Mass = 1.0f;
  mando1_MotionState = new btDefaultMotionState( btTransform( btQuaternion(0,0,0,1), escala * btVector3( 0.0f, 0.16f, 2.7f ) ) );
  mando_Shape->calculateLocalInertia( Mass, Inertia );
  mando1_RigidBody = new btRigidBody( Mass, mando1_MotionState, mando_Shape, Inertia );
  dynamicsWorld->addRigidBody( mando1_RigidBody );
    mando1_RigidBody->setDamping( btScalar( 0.0f ) , btScalar( 0.0f ) );
    mando1_RigidBody->setFriction(    btScalar( 0.0f ) );
    mando1_RigidBody->setRestitution( btScalar( 0.2f ) );
    mando1_RigidBody->setLinearFactor(  btVector3( 1.0f, 0.0f, 1.0f ) );
    mando1_RigidBody->setAngularFactor( btVector3( 0.0f, 0.0f, 0.0f ) );
    mando1_RigidBody->setActivationState( DISABLE_DEACTIVATION ); // Evita la Desctivaci�n.

  mando2_MotionState = new btDefaultMotionState( btTransform( btQuaternion(0,0,0,1), escala * btVector3( 0.0f, 0.16f, -2.7f ) ) );
  mando2_RigidBody = new btRigidBody( Mass, mando2_MotionState, mando_Shape, Inertia );
  dynamicsWorld->addRigidBody( mando2_RigidBody );
    mando2_RigidBody->setDamping( btScalar( 0.0f ) , btScalar( 0.0f ) );
    mando2_RigidBody->setFriction(    btScalar( 0.0f ) );
    mando2_RigidBody->setRestitution( btScalar( 0.2f ) );
    mando2_RigidBody->setLinearFactor(  btVector3( 1.0f, 0.0f, 1.0f ) );
    mando2_RigidBody->setAngularFactor( btVector3( 0.0f, 0.0f, 0.0f ) );
    mando2_RigidBody->setActivationState( DISABLE_DEACTIVATION ); // Evita la Desctivaci�n.
    
  //----------------------------------------------------------------------------
  Mass = 0.2f;
  esfera_MotionState = new btDefaultMotionState( btTransform( btQuaternion(0,0,0,1), escala * btVector3( 0.0f, 6.0f, 0.8f ) ) );
  esfera_Shape->calculateLocalInertia( Mass, Inertia );
  esfera_RigidBody = new btRigidBody( Mass, esfera_MotionState, esfera_Shape, Inertia );
  dynamicsWorld->addRigidBody( esfera_RigidBody );
    esfera_RigidBody->setDamping( btScalar( 0.5f ) , btScalar( 0.5f ) );
    esfera_RigidBody->setFriction(    btScalar( 0.5f ) );
    esfera_RigidBody->setRestitution( btScalar( 0.5f ) );
    
  //----------------------------------------------------------------------------
  Mass = 0.2f;
  cubo_MotionState = new btDefaultMotionState( btTransform( btQuaternion(0,0,0,1), escala * btVector3( 0.0f, 6.0f, -0.8f ) ) );
  cubo_Shape->calculateLocalInertia( Mass, Inertia );
  cubo_RigidBody = new btRigidBody( Mass, cubo_MotionState, cubo_Shape, Inertia );
  dynamicsWorld->addRigidBody( cubo_RigidBody );
    cubo_RigidBody->setDamping( btScalar( 0.5f ) , btScalar( 0.5f ) );
    cubo_RigidBody->setFriction(    btScalar( 0.5f ) );
    cubo_RigidBody->setRestitution( btScalar( 0.5f ) );

  //----------------------------------------------------------------------------
  Mass = 0.2f;
  cilindro_MotionState = new btDefaultMotionState( btTransform( btQuaternion(0,0,0,1), escala * btVector3( 0.0f, 6.0f, 0.0f ) ) );
  cilindro_Shape->calculateLocalInertia( Mass, Inertia );
  cilindro_RigidBody = new btRigidBody( Mass, cilindro_MotionState, cilindro_Shape, Inertia );
  dynamicsWorld->addRigidBody( cilindro_RigidBody );
    cilindro_RigidBody->setDamping( btScalar( 0.5f ) , btScalar( 0.5f ) );
    cilindro_RigidBody->setFriction(    btScalar( 0.5f ) );
    cilindro_RigidBody->setRestitution( btScalar( 0.5f ) );
  //----------------------------------------------------------------------------
    
}

c_bullet::~c_bullet( void ) {
  //------------------------------------------------------
  //-- Borrando Cuerpos R�gidos. ( Clean Rigid Bodies ) --
  //------------------------------------------------------
  dynamicsWorld->removeRigidBody( cilindro_RigidBody );
  delete cilindro_RigidBody->getMotionState();
  delete cilindro_RigidBody;
  
  dynamicsWorld->removeRigidBody( cubo_RigidBody );
  delete cubo_RigidBody->getMotionState();
  delete cubo_RigidBody;

  dynamicsWorld->removeRigidBody( esfera_RigidBody );
  delete esfera_RigidBody->getMotionState();
  delete esfera_RigidBody;

  dynamicsWorld->removeRigidBody( mando2_RigidBody );
  delete mando2_RigidBody->getMotionState();
  delete mando2_RigidBody;
  
  dynamicsWorld->removeRigidBody( mando1_RigidBody );
  delete mando1_RigidBody->getMotionState();
  delete mando1_RigidBody;

  dynamicsWorld->removeRigidBody( ficha_RigidBody );
  delete ficha_RigidBody->getMotionState();
  delete ficha_RigidBody;
  
  dynamicsWorld->removeRigidBody( mesa_RigidBody );
  delete mesa_RigidBody->getMotionState();
  delete mesa_RigidBody;
 
  //-------------------------------------------------------------
  //-- Borrando Formas de Colisi�n. ( Clean Collision Shapes ) --
  //-------------------------------------------------------------
  int NumChildShapes = mesa_Shape->getNumChildShapes();
  for ( int i = 0; i < NumChildShapes; ++i ) mesa_Shape->removeChildShapeByIndex( 0 );
  delete tabla_Shape;
  delete lateral_Shape;
  delete frontal_Shape;
  delete tapa_Shape;
  delete mesa_Shape;
  
  NumChildShapes = mando_Shape->getNumChildShapes();
  for ( int i = 0; i < NumChildShapes; ++i ) mando_Shape->removeChildShapeByIndex( 0 );
  delete mando_Shape;
  delete esfera_Shape;
  delete cilindro_Shape;
    
  delete ficha_Shape;  
  delete cubo_Shape;

  //-----------------------------------
  //-- Borrando el mundo y compa�ia. --
  //-----------------------------------
  delete dynamicsWorld;
  delete solver;
  delete collisionConfiguration;
  delete dispatcher;
  delete broadphase;                    
}

void c_bullet::inicia( void ) {
  ejecutado = 0.0f;
  x = V_Ancho >> 1; y = Uint16( V_Alto / 1.5f ); 
  camara_x = 0.0f; 
  camara_z = 2.75436;
  velocidad_x = 0.0f; 
  velocidad_z = 0.0f;
  switch( NIVEL ) {
    case 1:
      TOPE1 = 90.0f; TOPE2 = 30.0f; TOPE_reflejo = FOTOGRAMAS;
    break; 
    case 2:
      TOPE1 = 85.0f; TOPE2 = 40.0f; TOPE_reflejo = FOTOGRAMAS >> 1;
    break; 
    case 3:
      TOPE1 = 70.0f; TOPE2 = 50.0f; TOPE_reflejo = FOTOGRAMAS >> 2;
    break; 
    case 4:
      TOPE1 = 75.0f; TOPE2 = 60.0f; TOPE_reflejo = FOTOGRAMAS >> 3;
    break; 
    case 5:
      TOPE1 = 70.0f; TOPE2 = 70.0f; TOPE_reflejo = 1;
    break; 
    default:
      TOPE1 = 70.0f; TOPE2 = 70.0f; TOPE_reflejo = 1;
    break;
  }  
  impulso_x = 0.0f; 
  impulso_z = 0.0f;
  ultimo_gol = 0.0f; 
  volumen = 0;
  reflejo = 0; 
  estrategia = 0;
  sonido_choque = false; 
  sonido_tanto  = false;
  Puntos_1 = 0; 
  Puntos_2 = 0;

  mando1_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, 0.16f, 2.7f ) );
  mando1_RigidBody->setLinearVelocity(  btVector3( 0.0f, 0.0f, 0.0f ) );
  mando1_RigidBody->setAngularVelocity( btVector3( 0.0f, 0.0f, 0.0f ) );

  mando2_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, 0.16f, -2.7f ) );
  mando2_RigidBody->setLinearVelocity(  btVector3( 0.0f, 0.0f, 0.0f ) );
  mando2_RigidBody->setAngularVelocity( btVector3( 0.0f, 0.0f, 0.0f ) );
  
  ficha_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, 0.19f, 0.0f ) );
  ficha_RigidBody->setLinearVelocity(  btVector3( 0.0f, 0.0f, 0.0f ) );
  ficha_RigidBody->setAngularVelocity( btVector3( 0.0f, 0.0f, 0.0f ) );

  esfera_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, 6.0f, 0.8f ) );
  esfera_RigidBody->setLinearVelocity(  btVector3( 0.0f, 0.0f, 0.0f ) );
  esfera_RigidBody->setAngularVelocity( btVector3( 0.0f, 0.0f, 0.0f ) );

  cubo_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, 6.0f, -0.8f ) );
  cubo_RigidBody->setLinearVelocity(  btVector3( 0.0f, 0.0f, 0.0f ) );
  cubo_RigidBody->setAngularVelocity( btVector3( 0.0f, 0.0f, 0.0f ) );

  cilindro_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, 6.0f, 0.0f ) );
  cilindro_RigidBody->setLinearVelocity(  btVector3( 0.0f, 0.0f, 0.0f ) );
  cilindro_RigidBody->setAngularVelocity( btVector3( 0.0f, 0.0f, 0.0f ) );

  esfera_RigidBody->activate();
  cubo_RigidBody->activate();
  cilindro_RigidBody->activate();
  dynamicsWorld->synchronizeMotionStates();
  dynamicsWorld->stepSimulation( btScalar( retardo ) );
  if ( TANTOS_1 == 0 ) esfera_RigidBody->activate();
  else                 esfera_RigidBody->forceActivationState( 2 );
  if ( TANTOS_2 == 0 ) cubo_RigidBody->activate();
  else                 cubo_RigidBody->forceActivationState( 2 );
  if ( TANTOS_3 == 0 ) cilindro_RigidBody->activate();
  else                 cilindro_RigidBody->forceActivationState( 2 );
  dynamicsWorld->stepSimulation( btScalar( retardo ) );
}

void c_bullet::dibuja( btRigidBody* n_RigidBody, GLuint n_lista ) {
  glPushMatrix();
    trans.setIdentity();
    n_RigidBody->getMotionState()->getWorldTransform( trans );
    origen = trans.getOrigin();
    trans.setOrigin( origen / escala ); 
    trans.getOpenGLMatrix( m );
    glMultMatrixf( (const GLfloat *) m );
    glCallList( n_lista );
  glPopMatrix();
}

void c_bullet::dibuja_todo( GLuint lista, GLfloat *luz_pos ) { 
  if ( SOMBRAS || REFLEJOS ) {
    // -- DIBUJAR SUELO Y MASCARA ( GL_STENCIL_TEST ) --------------------------
    Hacer_Mascara_Sombra();
      glCallList( lista );
    Terminar_Mascara_Sombra();
    if ( SOMBRAS ) {
      // -- DIBUJAR LAS SOMBRAS --------------------------------------------------
      Hacer_Sombra( Plano, luz_pos );
      material[4].activa();
        dibuja( mando1_RigidBody,   lista + 2 );
        dibuja( mando2_RigidBody,   lista + 2 );
        dibuja( ficha_RigidBody,    lista + 4 );
        dibuja( esfera_RigidBody,   lista + 6 );
        dibuja( cubo_RigidBody,     lista + 7 );
        dibuja( cilindro_RigidBody, lista + 8 );
      material[4].desactiva();
      Terminar_Sombra();
    }
    if ( REFLEJOS ) {
      // -- DIBUJAR LOS REFLEJOS -------------------------------------------------
      glPushMatrix(); 
        glTranslatef(  0.0f, -0.25f, 0.0f );
        material[1].alpha( 0.2f ); material[1].activa();
          dibuja( mando1_RigidBody, lista + 2 );
        material[1].alpha( 1.0f ); 
        material[2].alpha( 0.2f ); material[2].activa();
          dibuja( mando2_RigidBody, lista + 2 );
        material[2].alpha( 1.0f );
        glTranslatef(  0.0f, 0.15f, 0.0f );
        material[3].alpha( 0.2f ); material[3].activa();
          dibuja( ficha_RigidBody, lista + 4 );
        material[3].alpha( 1.0f );
      glPopMatrix();       
      trans.setIdentity();
      esfera_RigidBody->getMotionState()->getWorldTransform( trans );
      origen = trans.getOrigin() / escala;
      if ( origen.getY() < 2.0f ) {
        glPushMatrix();
          glTranslatef(  0.0f, GLfloat( origen.getY() * -2.0f ) + 0.15f, 0.0f );
          material[0].alpha( 0.2f ); material[0].activa();
            dibuja( esfera_RigidBody, lista + 6 );
          material[0].alpha( 1.0f );
        glPopMatrix();
      }
      trans.setIdentity();
      cubo_RigidBody->getMotionState()->getWorldTransform( trans );
      origen = trans.getOrigin() / escala;
      if ( origen.getY() < 2.0f ) {
        glPushMatrix();
          glTranslatef(  0.0f, GLfloat( origen.getY() * -2.0f ) + 0.15f, 0.0f );
          material[0].alpha( 0.2f ); material[0].activa();
            dibuja( cubo_RigidBody, lista + 7 );
          material[0].alpha( 1.0f );
        glPopMatrix();
      }
      trans.setIdentity();
      cilindro_RigidBody->getMotionState()->getWorldTransform( trans );
      origen = trans.getOrigin() / escala;
      if ( origen.getY() < 2.0f ) {
        glPushMatrix();
          glTranslatef(  0.0f, GLfloat( origen.getY() * -2.0f  ) + 0.15f, 0.0f );
          material[0].alpha( 0.2f ); material[0].activa();
            dibuja( cilindro_RigidBody, lista + 8 );
          material[0].alpha( 1.0f );
        glPopMatrix();
      }     
    }
    Fin_Sombras();
  } else {
    glCallList( lista );
  }
  // -- DIBUJAR LOS OBJETOS --------------------------------------------------
  material[1].activa();
    dibuja( mando1_RigidBody,   lista + 3 );
  material[2].activa();
    dibuja( mando2_RigidBody,   lista + 3 );
  material[3].activa();
    dibuja( ficha_RigidBody,    lista + 5 );
  material[0].activa();
    dibuja( esfera_RigidBody,   lista + 6 );
    dibuja( cubo_RigidBody,     lista + 7 );
    dibuja( cilindro_RigidBody, lista + 8 );
    glCallList( lista + 1 );
}

void c_bullet::se_ha_salido( btRigidBody* n_RigidBody, float altura ) {
  trans.setIdentity();
  n_RigidBody->getMotionState()->getWorldTransform(trans);
  if ( trans.getOrigin().getY() < 0.0f ) {
    n_RigidBody->setLinearVelocity(  btVector3( 0.0f, 0.0f, 0.0f ) );
    n_RigidBody->setAngularVelocity( btVector3( 0.0f, 0.0f, 0.0f ) );
    n_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, altura, 0.0f ) );
  } 
}

void c_bullet::que_no_se_escape_nadie( void ) {
  se_ha_salido( esfera_RigidBody,   2.0f  );
  se_ha_salido( cubo_RigidBody,     2.0f  );
  se_ha_salido( cilindro_RigidBody, 2.0f  );
}

void c_bullet::donde_esta_la_ficha( void ) {
  trans.setIdentity();
  ficha_RigidBody->getMotionState()->getWorldTransform(trans);
  origen = trans.getOrigin() / escala;
  if ( Punto_en_Juego ) { 
    // * * * GOL DEL AZUL * * *
    if ( origen.getZ() < -3.1f ) {
      Punto_en_Juego = false;
      if ( ( origen.getY() <= 0.3f ) && ( origen.getY() >= 0.1f ) ) {
        sonido_tanto = true; ++Puntos_1; ultimo_gol = -0.5f;
        if ( TOPE2 < 100.0f ) TOPE2 += 6; 
        if ( TOPE_reflejo > 2 ) --TOPE_reflejo;
        if ( Puntos_1 == TANTOS_1 ) esfera_RigidBody->activate();
        if ( Puntos_1 == TANTOS_2 ) cubo_RigidBody->activate();
        if ( Puntos_1 == TANTOS_3 ) cilindro_RigidBody->activate();
        if ( Puntos_1 == GANAR ) sdl_con_opengl->terminar = true;
        mando1_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, 0.16f, 2.7f ) );
        SDL_WarpMouse( V_Ancho >> 1, Uint16( V_Alto / 1.5f ) );
      }
    }       
    // * * * GOL DEL ROJO * * *
    else if ( origen.getZ() >  3.1f ) {
      Punto_en_Juego = false;
      if ( ( origen.getY() <= 0.2f ) && ( origen.getY() >= 0.1f ) ) {
        sonido_tanto = true; ++Puntos_2; ultimo_gol = 0.5f;
        if ( TOPE1 < 100.0f ) TOPE1 += 2; 
        if ( Puntos_2 >= GANAR ) sdl_con_opengl->terminar = true;
        mando1_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, 0.16f, 2.7f ) );
        SDL_WarpMouse( V_Ancho >> 1, Uint16( V_Alto / 1.5f ) );
      }
    }
  }
  if ( origen.getY() < 0.0f ) {
    Punto_en_Juego = true;
    ficha_RigidBody->clearForces();
    ficha_RigidBody->setAngularVelocity(  btVector3( 0.0f, 0.0f, 0.0f )              );
    ficha_RigidBody->setLinearVelocity(   btVector3( 0.0f, 0.0f, ultimo_gol * 2.0f ) );
    ficha_RigidBody->applyCentralImpulse( btVector3( 0.0f, 0.0f, ultimo_gol * 2.0f ) );
    ficha_RigidBody->getWorldTransform().setOrigin( escala * btVector3( 0.0f, 0.19f, ultimo_gol ) );
    dynamicsWorld->stepSimulation( retardo, 10 );
  } else if ( origen.getY() > 2.0f ) {
    ficha_RigidBody->getWorldTransform().setOrigin( escala * btVector3( origen.getX(), 0.19f, origen.getZ() ) );
    dynamicsWorld->synchronizeSingleMotionState( ficha_RigidBody );
  }
}
    
void c_bullet::camara( void ) {
  trans.setIdentity();
  mando1_RigidBody->getMotionState()->getWorldTransform(trans);
  origen = trans.getOrigin() / escala;
  camara_x += ( origen.getX() - camara_x ) / 64.0f;
  if ( origen.getZ() < camara_z )
    camara_z += ( origen.getZ() - camara_z ) / 512.0f;
  else
    camara_z += ( origen.getZ() - camara_z ) / 8.0f;
  sdl_con_opengl->enfoque_camara(  camara_x, camara_z - 2.1f );
  sdl_con_opengl->posicion_camara( camara_x, camara_z + 1.8f );
}

void c_bullet::simulacion( void ) {
  ejecutado = sdl_con_opengl->dame_retardo();
  if ( ejecutado < retardo ) 
    for ( int i = 0; i < MOTOR_FISICO; i++ ) dynamicsWorld->stepSimulation( btScalar( retardo / MOTOR_FISICO ), 0, btScalar( retardo ) );
  else
    for ( int i = 0; i < MOTOR_FISICO; i++ ) dynamicsWorld->stepSimulation( btScalar( ejecutado / MOTOR_FISICO ), 0, btScalar( ejecutado ) );
}

void c_bullet::control_mando_1( void ) {
  trans.setIdentity();
  mando1_RigidBody->getMotionState()->getWorldTransform(trans);
  origen = trans.getOrigin() / escala;
  trans.setIdentity();
  ficha_RigidBody->getMotionState()->getWorldTransform(trans);
  destino = trans.getOrigin() / escala;
  if ( ( destino.getZ() > 2.8f ) && ( ( destino.getX() > 1.3f ) || ( destino.getX() < -1.3f ) ) )
    ficha_RigidBody->applyCentralImpulse( btVector3( 0.0f, 0.0f, -0.05f ) );
  glGetDoublev(  GL_MODELVIEW_MATRIX,  model    );
  glGetDoublev(  GL_PROJECTION_MATRIX, proj     );
  glGetIntegerv( GL_VIEWPORT,          viewport );    
  gluProject( origen.getX(), origen.getY(), origen.getZ(), model, proj, viewport, &winOX, &winOY, &winOZ ); 
  gluProject( destino.getX(), destino.getY(), destino.getZ(), model, proj, viewport, &winDX, &winDY, &winDZ );
  x = sdl_con_opengl->dame_raton_x();
  y = sdl_con_opengl->dame_raton_y();
  //-- LIMITAR EL RECORRIDO DEL CURSOR -----------------------------------------
  gluUnProject( GLdouble(x), GLdouble(y), winOZ, model, proj, viewport, &cursor_X, &cursor_Y, &cursor_Z );
  if ( cursor_X < -1.35 ) {
    gluProject( -1.35, cursor_Y, cursor_Z, model, proj, viewport, &limite_X, &limite_Y, &limite_Z );
    x = int( limite_X ); SDL_WarpMouse( x, V_Alto - y - 1 );
  } else if ( cursor_X > 1.35 ) {
    gluProject( 1.35, cursor_Y, cursor_Z, model, proj, viewport, &limite_X, &limite_Y, &limite_Z );
    x = int(limite_X); SDL_WarpMouse( x, V_Alto - y - 1 );
  }
  if ( cursor_Z < 0.2 ) {
    gluProject( cursor_X, cursor_Y, 0.2, model, proj, viewport, &limite_X, &limite_Y, &limite_Z );
    y = int( limite_Y ); SDL_WarpMouse( x, V_Alto - y );
  } else if ( cursor_Z > 2.8 ) {
    gluProject( cursor_X, cursor_Y, 2.8, model, proj, viewport, &limite_X, &limite_Y, &limite_Z );
    y = int( limite_Y ); SDL_WarpMouse( x, V_Alto - y ); 
  }
  //-- DIRECCI�N ASISTIDA ------------------------------------------------------
  if ( DIRECCION_ASISTIDA ) {
    distancia = btDistance2( origen, destino );
    if ( ( distancia < 3.0f ) && ( origen.getZ() > destino.getZ() ) ) { 
      x += int( ( winDX - winOX ) / ( 8.0f * distancia ) );
      y += int( ( winDY - winOY ) / ( 8.0f * distancia ) );
    }
  }
  impulso_x = ( (GLfloat)x - (GLfloat)winOX );
  impulso_z = ( (GLfloat)winOY - (GLfloat)y );
  if      ( impulso_x >  TOPE1 ) impulso_x =  TOPE1; 
  else if ( impulso_x < -TOPE1 ) impulso_x = -TOPE1;
  if      ( impulso_z >  TOPE1 ) impulso_z =  TOPE1; 
  else if ( impulso_z < -TOPE1 ) impulso_z = -TOPE1;
  if ( origen.getZ() < 0.2f ) {
    mando1_RigidBody->getWorldTransform().setOrigin( escala * btVector3( origen.getX(), 0.16f, 0.2f ) );
    mando1_RigidBody->setLinearVelocity( btVector3( btScalar( impulso_x ), 0.0f, btScalar( impulso_z ) ) ); }
  else if ( !Punto_en_Juego )
    mando1_RigidBody->setLinearVelocity( btVector3( btScalar(( 0.0f - origen.getX() ) * 60.0f ), 0.0f, btScalar( ( 2.8f - origen.getZ() ) * 60.0f ) ) );
  else 
    mando1_RigidBody->setLinearVelocity( btVector3( btScalar( impulso_x ), 0.0f, btScalar( impulso_z ) ) );
}

void c_bullet::control_mando_2( void ) {
  trans.setIdentity();
  mando2_RigidBody->getMotionState()->getWorldTransform( trans );
  origen = trans.getOrigin() / escala;
  trans.setIdentity();
  ficha_RigidBody->getMotionState()->getWorldTransform( trans );
  destino = trans.getOrigin() / escala;
  distancia  = btDistance2( origen, destino );
  velocidad = ficha_RigidBody->getLinearVelocity(); 
  if ( reflejo == 0 ) {
    estrategia = 0;
    //-- CUBRIR LA PORTERIA --
    if ( ( destino.getZ() -0.18f ) > origen.getZ() ) estrategia = 0;
    //-- ACERCARSE A LA FICHA --
    if ( ( destino.getZ() <=  0.0f ) && 
         ( origen.getZ() <= destino.getZ() ) && 
         ( distancia > 3.0f ) ) estrategia = 1;
    //-- GOLPEAR --
    if ( ( destino.getZ() <  0.0f ) && 
         ( origen.getZ() <= destino.getZ() ) && 
         ( distancia <= 3.0f ) &&
         ( velocidad.getZ() < 6.0f ) ) estrategia = 2;
    //-- CUBRIR EN MEDIO --
    if ( destino.getY() < 0.1f ) estrategia = 3;
    //-- FICHA PARADA --
    if ( ( destino.getZ() <=  0.0f ) &&  ( velocidad.getZ() > -0.1f ) && ( velocidad.getZ() < 0.1f ) ) estrategia = 1;
    //-- ESQUINA --
    if ( ( destino.getZ() < -2.8f ) && ( ( destino.getX() > 1.3f ) || ( destino.getX() < -1.3f ) ) ) estrategia = 4;
  } ++reflejo; if ( reflejo > TOPE_reflejo ) reflejo = 0;
  switch( estrategia ) {   
    case 0: //-- CUBRIR LA PORTERIA --
      impulso_x = ( (destino.getX() / 1.5f) - origen.getX() ) * 60.0f;
      impulso_z = -100.0f / distancia; break;
    case 1: //-- ACERCARSE A LA FICHA --
      impulso_x = ( destino.getX() - origen.getX() ) * 40.0f;
      impulso_z = ( destino.getZ() - origen.getZ() ) * 30.0f; break;
    case 2: //-- GOLPEAR --
      impulso_x = ( destino.getX() - origen.getX() ) * 70.0f;
      impulso_z = ( destino.getZ() - origen.getZ() ) * 200.0f;
      if ( distancia < 0.1f ) ficha_RigidBody->applyCentralImpulse( btVector3( rnd_float( -1.0f, 1.0f ), 0.0f, rnd_float( 0.0f, 1.0f ) ) );
    break;
    case 3: //-- CUBRIR EN MEDIO --
      impulso_x = ( 0.0f - origen.getX() ) * 60.0f;
      impulso_z = -100.0f / distancia; break;
    case 4:   //-- ESQUINA --
      impulso_x = ( 0.0f - origen.getX() ) * 200.0f;
      impulso_z = -100.0f;
      ficha_RigidBody->applyCentralImpulse( btVector3( 0.0f, 0.0f, 0.05f ) ); break;
    default:
      impulso_x = ( destino.getX() - origen.getX() ) * 60.0f;
      impulso_z = -100.0f / distancia; break;   
  }
  if      ( impulso_x >  TOPE2 ) impulso_x =  TOPE2; 
  else if ( impulso_x < -TOPE2 ) impulso_x = -TOPE2;
  if      ( impulso_z >  TOPE2 ) impulso_z =  TOPE2; 
  else if ( impulso_z < -TOPE2 ) impulso_z = -TOPE2;
  if ( origen.getZ() > -0.2f )
    mando2_RigidBody->setLinearVelocity( btVector3( btScalar( impulso_x ), 0.0f, btScalar( -5.0f ) ) );
  else
    mando2_RigidBody->setLinearVelocity( btVector3( btScalar( impulso_x ), 0.0f, btScalar( impulso_z ) ) );
  //-- Sonido Choque -----------------------------------------------------------
  if ( SONIDO ) {
    if ( ( velocidad.getZ() > 3.1f ) && ( velocidad_z < 3.1f ) ) sonido_choque = true;
    if ( ( velocidad.getZ() < 3.1f ) && ( velocidad_z > 3.1f ) ) sonido_choque = true;
    if ( ( velocidad.getX() > 3.1f ) && ( velocidad_x < 3.1f ) ) sonido_choque = true;
    if ( ( velocidad.getX() < 3.1f ) && ( velocidad_x > 3.1f ) ) sonido_choque = true;
    velocidad_x = velocidad.getX();
    velocidad_z = velocidad.getZ();
    if ( sonido_choque ) {
      volumen = Uint8( ( velocidad.length2() * 128 ) / 10000 ) + 1;
      if ( volumen > 128 ) volumen = 128;
    }
  }
}
