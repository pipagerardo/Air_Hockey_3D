//------------------------------------------------------------------------------
//-- TUTORIAL SDL + OPENGL ( Programado en C++ con Dev-C++ 4.9.9.2 )          --
//------------------------------------------------------------------------------
//-- AUTOR: PIPAGERARDO                                                       --
//-- EMAIL: pipagerardo@hotmail.es                                            --
//-- SUGERENCIAS: (Foros privados de programaci�n) www.scenebeta.com          --
//-- FECHA �LTIMA MODIFICACI�N: 28/08/2010                                    --
//------------------------------------------------------------------------------
//-- Todo  el  c�digo  y  contenido  de  este  tutorial es exclusivo  para el --
//-- aprendizaje tanto del autor como de los que colaboren en �l. Sin el  m�s --
//-- m�nimo �nimo de lucro, siempre por la satisfacci�n del aprendizaje y del --
//-- trabajo bien hecho.                                                      --
//-- No  me  hago  responsable  del  da�o  producido  por  el  uso  indebido, --
//-- modificaciones  mal  intencionadas,  �nimo  de  lucro,  etc...           --
//-- Solo pido al que le sea de utilidad este c�digo que colabore en su mejora--
//-- y perfeccionamiento poni�ndomelo en conocimiento por correo electr�nico. --
//------------------------------------------------------------------------------

#ifndef _Bullet_
#define _Bullet_

#include <btBulletDynamicsCommon.h>
#include <GL/gl.h>										
#include <GL/glu.h>										
#include <SDL/SDL.h>
#include "../Includes/SDL_con_OpenGL.h"
#include "../Includes/Aleatorio.h"
#include "../Includes/Sombras.h"
#include "../Includes/Materiales.h"

class c_bullet {
  public:
    c_bullet( c_sdl_con_opengl* puntero, c_material *puntero_mat );
    ~c_bullet( void );
    void inicia( void ); 
    void dibuja_todo( GLuint lista, GLfloat *luz_pos );
    void que_no_se_escape_nadie( void );
    void donde_esta_la_ficha( void );
    void camara( void ); 
    void simulacion( void );
    void control_mando_1( void );
    void control_mando_2( void );
    bool Punto_en_Juego;
    int  Puntos_1, Puntos_2;
    bool sonido_choque, sonido_tanto;
    Uint8 volumen;
  private:
    void dibuja( btRigidBody* n_RigidBody, GLuint n_lista );
    void se_ha_salido( btRigidBody* n_RigidBody, float altura ); 

    //--------------------------------------------------------------------------
    //-- VARIABLES.                                                           --
    //--------------------------------------------------------------------------
    c_sdl_con_opengl* sdl_con_opengl;
    c_material *material;
    
    
    float       retardo; 
    float       ejecutado;
    int         x, y;                // COORDENADAS DEL RAT�N.
    GLfloat     camara_x, camara_z;
    btScalar    escala;
    btScalar    Mass;         //-- Masa del cuerpo en Kilos. 0 es masa infinita --
    btVector3   Inertia;      //-- Inercia del cuerpo. --
    btTransform trans;
    btVector3   origen;
    btVector3   destino;
    btScalar    m[16];
    GLdouble    model[16];            // MATRIZ DE MODELADO.
    GLdouble    proj[16];             // MATRIZ DE PROYECCION.
    GLint       viewport[4];          // VENTANA DE VISUALIZACI�N.
    GLdouble    winOX, winOY, winOZ;  // COORDENADAS DE LA VENTANA DE VISUALIZACI�N. 
    GLdouble    winDX, winDY, winDZ;
    GLdouble    cursor_X, cursor_Y, cursor_Z;  
    GLdouble    limite_X, limite_Y, limite_Z;
    GLfloat     TOPE1, TOPE2;
    float       distancia;
    btVector3   velocidad;
    btScalar    velocidad_x;
    btScalar    velocidad_z;
    char        estrategia;
    GLfloat     impulso_x, impulso_z;
    GLfloat     ultimo_gol;
    int         reflejo, TOPE_reflejo;

    GLfloat Puntos[9];
    GLfloat Plano[4];

    //--------------------------------------------------------------------------
    //-- LIBRER�A DE F�SICA BULLET                                            --
    //--------------------------------------------------------------------------
    btBroadphaseInterface*               broadphase;
    btDefaultCollisionConfiguration*     collisionConfiguration;
    btCollisionDispatcher*               dispatcher;
    btSequentialImpulseConstraintSolver* solver;       
    btDiscreteDynamicsWorld*             dynamicsWorld;

    //--------------------------------------------------------------------------
    //-- Formas de Colisi�n ( Collision Shapes )                              --
    //--------------------------------------------------------------------------
    btCollisionShape* tabla_Shape;
    btCollisionShape* lateral_Shape;
    btCollisionShape* frontal_Shape;
    btCollisionShape* tapa_Shape;
    btCompoundShape*  mesa_Shape; 
    btCollisionShape* ficha_Shape;
    btCollisionShape* esfera_Shape;
    btCollisionShape* cilindro_Shape;
    btCompoundShape*  mando_Shape;   
    btCollisionShape* cubo_Shape;

    //--------------------------------------------------------------------------
    //-- Cuerpos r�gidos. ( Rigid Bodies )                                    --
    //--------------------------------------------------------------------------
    btDefaultMotionState* mesa_MotionState;
    btRigidBody* mesa_RigidBody;
  
    btDefaultMotionState* ficha_MotionState;
    btRigidBody* ficha_RigidBody;

    btDefaultMotionState* mando1_MotionState;
    btRigidBody* mando1_RigidBody;
    
    btDefaultMotionState* mando2_MotionState;
    btRigidBody* mando2_RigidBody;

    btDefaultMotionState* esfera_MotionState;
    btRigidBody* esfera_RigidBody;

    btDefaultMotionState* cubo_MotionState;
    btRigidBody* cubo_RigidBody;

    btDefaultMotionState* cilindro_MotionState;
    btRigidBody* cilindro_RigidBody;
};

#endif
